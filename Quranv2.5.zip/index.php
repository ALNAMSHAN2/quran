<?php
include "inc/hader.php";
?>
<?php
$sedanycom= "www.sedany.com";
$sedany= "<div class= sedany > <a title=سيداني   target=_blank      href=http://$sedanycom > Powered by sedany.com  </a> </div>";
$Blok = "$SEDANY[2]";
$Bloklink="<li><a href='index.php?Quran=Abdulbasit_Mojawwad' class='link1'> $soot[1] </a></li>
<li><a href='index.php?Quran=Al-Ajmy' class='link1'> $soot[2] </a></li>
<li><a href='index.php?Quran=Abdulbasit' class='link1'>  $soot[3] </a></li>
<li><a href='index.php?Quran=Al-Minshawi' class='link1'> $soot[4]  </a></li>
<li><a href='index.php?Quran=Al-Minshawi_Mojawwad' class='link1'> $soot[5]  </a></li>
<li><a href='index.php?Quran=Alsudaes' class='link1'>   $soot[6]  </a></li>
<li><a href='index.php?Quran=Al-Johany' class='link1'>   $soot[7]  </a></li>
<li><a href='index.php?Quran=maher' class='link1'>   $soot[8] </a></li>
<li><a href='index.php?Quran=Al-Shuraim' class='link1'>  $soot[9] </a></li>
<li><a href='index.php?Quran=Al-Ghamdi' class='link1'> $soot[10] </a></li>
<li><a href='index.php?Quran=Fares' class='link1'>   $soot[11] </a></li>
<li><a href='index.php?Quran=Alafasi' class='link1'>  $soot[12] </a></li>
<li><a href='index.php?Quran=abdulkafi' class='link1'> $soot[40] </a></li>
<li><a href='index.php?Quran=adel-rayan' class='link1'> $soot[13] </a></li>
<li><a href='index.php?Quran=Al-Ahmad' class='link1'> $soot[33]  </a></li>
<li><a href='index.php?Quran=alakhdar' class='link1'>  $soot[17] </a></li>
<li><a href='index.php?Quran=Al-Dosari' class='link1'> $soot[23] </a></li>
<li><a href='index.php?Quran=Al-Hussary' class='link1'> $soot[45]  </a></li>
<li><a href='index.php?Quran=Ali-Alhuthaifi' class='link1'> $soot[50]  </a></li>
<li><a href='index.php?Quran=alkalbany' class='link1'> $soot[41] </a></li>
<li><a href='index.php?Quran=Al-Mattrod' class='link1'> $soot[46]  </a></li>
<li><a href='index.php?Quran=Al-Qahtani' class='link1'> $soot[47] </a></li>
<li><a href='index.php?Quran=al-qasim' class='link1'> $soot[30]  </a></li>
<li><a href='index.php?Quran=Al-Qazabri' class='link1'> $soot[48]  </a></li>
<li><a href='index.php?Quran=athobaity' class='link1'> $soot[42]  </a></li>
<li><a href='index.php?Quran=basfar' class='link1'> $soot[24] </a></li>
<li><a href='index.php?Quran=Bukhatir' class='link1'> $soot[34]  </a></li>
<li><a href='index.php?Quran=doukkali' class='link1'> $soot[35]  </a></li>
<li><a href='index.php?Quran=el-najjar' class='link1'> $soot[43]  </a></li>
<li><a href='index.php?Quran=Hani' class='link1'> $soot[14]  </a></li>
<li><a href='index.php?Quran=hatem' class='link1'> $soot[18]  </a></li>
<li><a href='index.php?Quran=Jaber' class='link1'>$soot[19]  </a></li>
<li><a href='index.php?Quran=jamal' class='link1'> $soot[20]  </a></li>
<li><a href='index.php?Quran=Jibrel' class='link1'> $soot[25]  </a></li>
<li><a href='index.php?Quran=Kanakeri' class='link1'> $soot[36]  </a></li>
<li><a href='index.php?Quran=khalifa' class='link1'> $soot[37]  </a></li>
<li><a href='index.php?Quran=khayat' class='link1'> $soot[26]  </a></li>
<li><a href='index.php?Quran=Mohamad-Abdullkarem' class='link1'> $soot[44]  </a></li>
<li><a href='index.php?Quran=muslim' class='link1'> $soot[27]  </a></li>
<li><a href='index.php?Quran=nabil' class='link1'> $soot[21] </a></li>
<li><a href='index.php?Quran=Sahl-Yassin' class='link1'> $soot[49]  </a></li>
<li><a href='index.php?Quran=Salah-Albudair' class='link1'> $soot[38]  </a></li>
<li><a href='index.php?Quran=Shatri' class='link1'> $soot[28]  </a></li>
<li><a href='index.php?Quran=Shirazad-Taher' class='link1'> $soot[39]  </a></li>
<li><a href='index.php?Quran=soufi' class='link1'> $soot[22]  </a></li>
<li><a href='index.php?Quran=Tawfeeq-As-Sayegh' class='link1'> $soot[31]  </a></li>
<li><a href='index.php?Quran=yaseen' class='link1'> $soot[29]  </a></li>
<li><a href='index.php?Quran=youssef' class='link1'> $soot[32]</a></li>
<li><a href='index.php?Quran=zain' class='link1'> $soot[15]  </a></li>
<li><a href='index.php?Quran=zaki' class='link1'> $soot[16]  </a></li>
<li><a href='index.php?Quran=abdelmoujib-benkirane' class='link1'>  عبدالمجيب بنكيران </a></li>
<li><a href='index.php?Quran=abdlkaber' class='link1'> عبد الكبير الحديدي  </a></li>
<li><a href='index.php?Quran=Abdulmuhsin-Al-Harthy' class='link1'> عبدالمحسن الحارثي  </a></li>
<li><a href='index.php?Quran=abdulqawi-abdulmajid' class='link1'> عبد القوي عبد المجيد  </a></li>
<li><a href='index.php?Quran=abdulrhman-aljuraidy' class='link1'> عبدالرحمن الجريذي  </a></li>
<li><a href='index.php?Quran=abkar' class='link1'>  إدريس أبكر  </a></li>
<li><a href='index.php?Quran=ahmed-attarabolsi' class='link1'>  أحمد خضر الطرابلسي  </a></li>
<li><a href='index.php?Quran=ahmed-neana' class='link1'> أحمد نعينع  </a></li>
<li><a href='index.php?Quran=Al-Arkani' class='link1'>  عبدالولي الأركاني  </a></li>
<li><a href='index.php?Quran=Al-Asiri' class='link1'>  إبراهيم العسيري  </a></li>
<li><a href='index.php?Quran=albana' class='link1'>  محمود علي البنا  </a></li>
<li><a href='index.php?Quran=albana_mjwd' class='link1'>  محمود علي البنا  </a></li>
<li><a href='index.php?Quran=Al-Barrak' class='link1'> محمد البراك </a></li>
<li><a href='index.php?Quran=alhashim' class='link1'>     صلاح الهاشم </a></li>
<li><a href='index.php?Quran=Al-Kandari' class='link1'>     فهد الكندري </a></li>
<li><a href='index.php?Quran=Al-Lohaidan' class='link1'>   محمد اللحيدان  </a></li>
<li><a href='index.php?Quran=Al-Minshawi_Mojawwad' class='link1'> محمد صديق المنشاوي </a></li>
<li><a href='index.php?Quran=Al-Oni' class='link1'>  لافي العوني  </a></li>
<li><a href='index.php?Quran=Alqatami' class='link1'>  ناصر القطامي  </a></li>
<li><a href='index.php?Quran=ayman-aldeeb' class='link1'>   أيمن أحمد الديب  </a></li>
<li><a href='index.php?Quran=Ayyub' class='link1'>     محمد أيوب  </a></li>
<li><a href='index.php?Quran=azzawi' class='link1'>  مصطفى بن رعد العزاوي  </a></li>
<li><a href='index.php?Quran=elkantaoui' class='link1'>  محمد الكنتاوي  </a></li>
<li><a href='index.php?Quran=fouad-alkhamri' class='link1'>     فؤاد الخامري  </a></li>
<li><a href='index.php?Quran=hafez-ishak-danish' class='link1'>   حافظ إسحاق دانيش  </a></li>
<li><a href='index.php?Quran=haneef' class='link1'>  عبدالودود مقبول حنيف  </a></li>
<li><a href='index.php?Quran=hasan-mohamed-saleh-warsh' class='link1'> حسن محمد صالح </a></li>
<li><a href='index.php?Quran=hawashy' class='link1'>  أحمد الحواشي   </a></li>
<li><a href='index.php?Quran=jazza-alsuwaileh' class='link1'>  جزاع بن فليح الصويلح  </a></li>
<li><a href='index.php?Quran=jbreen' class='link1'>  ابراهيم الجبرين  </a></li>
<li><a href='index.php?Quran=jleel' class='link1'>  خالد الجليل   </a></li>
<li><a href='index.php?Quran=koshi' class='link1'>  العيون الكوشي </a></li>
<li><a href='index.php?Quran=lahoni' class='link1'>   مصطفى اللاهوني  </a></li>
<li><a href='index.php?Quran=mahmoud-rifai' class='link1'>  محمود الرفاعي  </a></li>
<li><a href='index.php?Quran=Mansoor' class='link1'>  منصور الزهراني  </a></li>
<li><a href='index.php?Quran=mhsny' class='link1'>   محمد المحيسني  </a></li>
<li><a href='index.php?Quran=mohamed-alabdulah' class='link1'>  محمد عبدالحكيم سعيد </a></li>
<li><a href='index.php?Quran=mohamed-elhodairi' class='link1'>   محمد الحضيري </a></li>
<li><a href='index.php?Quran=mohamed-hassan' class='link1'>  محمد حسان   </a></li>
<li><a href='index.php?Quran=mustafaismail' class='link1'>  مصطفى إسماعيل  </a></li>
<li><a href='index.php?Quran=salama-hdr' class='link1'> ياسر سلامة </a></li>
<li><a href='index.php?Quran=Sami-Al-Hasn' class='link1'>  سامي الحسن  </a></li>
<li><a href='index.php?Quran=shakhashero' class='link1'>   ماهر شخاشيرو  </a></li>
<li><a href='index.php?Quran=sultan-alrukan' class='link1'>  سلطان الروكان   </a></li>
<li><a href='index.php?Quran=tablawi' class='link1'>   محمد محمود الطبلاوي   </a></li>
<li><a href='index.php?Quran=Walid-Al-Dulaimi' class='link1'>  وليد الدليمي  </a></li>
<li><a href='index.php?Quran=yahya' class='link1'>  يحيى حوا  </a></li>
<li><a href='index.php?Quran=youssef-abkar' class='link1'>  يوسف أبكر   </a></li>
<li><a href='index.php?Quran=youssef-nouh' class='link1'>  يوسف نوح أحمد   </a></li>
<li><a href='index.php?Quran=zamil' class='link1'> ماجد الزامل  </a></li>
<li><a href='index.php?Quran=banr' class='link1'>  $SEDANY[11] </a></li>";
?>
<div class="com-sedany">
<div class="mw">
<div class="mw-right">
<div class="mw-left">
<!--هذا الكلاسات للاطراف-->
<div class="web"><div class="web-right">
<?php
include "inc/Blok.php";
?>
<div class="clr"> </div></div>
<div class="web-left">
<?php
include "inc/main-Quran.php";
?>
<div class="clr"> </div>
<div class="clr"> </div>
</div>
<div class="clr"> </div>
<?=$sedany;?>
</div><!--هذا الكلاسات للفوتر--></div>
</div>
</div></div>
<?php
include "inc/footer.php";
?>
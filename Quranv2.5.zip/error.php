<?php
$LANGUAGE[00] = "
<title>لقد اتبعت رابط غلط
- $sitename</title>
<div class='Quranbooxq'>
<ul>
<li><a href='./'> لقد اتبعت رابط غلط </a></li>
</ul>
</div>"; 
print $LANGUAGE[00];
?>
<?php
include "config.php";
$rss ="<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'><html dir='rtl'><head>
<title>$sitename
</title>
<meta http-equiv='Content-type' content='text/html; charset=utf-8' />
<style type='text/css'>
body {
margin: 0px;
background-color: #172B17;
}
#lxm {
margin: 0px auto 0px auto;
width: 750px;
background-color: #FFFFFF;
}
#lxm a {
display: block;
width: auto;
height: 20px;
text-decoration: none;
font-family: tahoma;
font-size: 12px;
color: #172B17;
margin-right: 5px;
}
#lxm a:hover{
border: 1px solid #008000;
background-color: #002800;
color: #FFFFFF;
}
#lxm h1 {
background-color: #fff;
padding: 20px;
color: #172B17;
text-align: right;
font-size: 40px;
margin: 0px;
font-family: tahoma;
font-weight: lighter;
}
#lxm h3 {
border: 1px solid #FFFFFF;
font-size: 12px;
background-color: #172B17;
margin: 0px;
padding: 10px;
font-family: tahoma;
color: #FFFFFF;
}
#lxm h3 a {
float: right;
font-weight: normal;
display: block;
color: #FFFFFF;
}
.lhead {
background-color:#fff;
padding:3px;
font-weight:bold;
font-size:16px;
}
.lcount {
background-color: #172B17;
color: #fff;
padding: 2px;
margin: 2px;
font: bold 12px verdana;
}
#footer {
border: 1px solid #FFFFFF;
background-color: #172B17;
padding: 10px;
text-align: center;
color: #FFFFFF;
}
#footer a{
color: #FFFFFF;
}
</style>
</head>
<body>
<div id='lxm'>
<h1>     $sitename  </h1>
<h3><a href='$wwwlink'>  $sitename  </a>
آخر تحديث :
</h3>
<div class='lhead'>/
<span class='lcount'> 454 صفحات  </span></div><a href='$wwwlink/'>$sitename </a>
<a href='$wwwlink/alla7.php'>الله</a>
<a href='$wwwlink/7tsmin.php'> الحديث النبوي الشريف </a>
<a href='$wwwlink/Do3a.php'>فضل الدعاء </a>
<a href='$wwwlink/files.php'> فلاش  أجمل عروس</a>
<a href='$wwwlink/vg.php'>رجال ونساء أسلموا </a>
<a href='$wwwlink/vip.php'>آدم عليه السلام</a>
<a href='$wwwlink/index.php?Quran=Abdulbasit_Mojawwad'>عبد الباسط عبد الصمد</a>
<a href='$wwwlink/index.php?Quran=Al-Ajmy'>أحمد بن علي العجمي</a>
<a href='$wwwlink/index.php?Quran=Abdulbasit'>عبد الباسط عبد الصمد</a> 
<a href='$wwwlink/index.php?Quran=Al-Minshawi'>محمد صديق المنشاوي</a> 
<a href='$wwwlink/index.php?Quran=Al-Minshawi_Mojawwad'>محمد صديق المنشاوي</a>
<a href='$wwwlink/index.php?Quran=Alsudaes'> عبدالرحمن السديس </a>
<a href='$wwwlink/index.php?Quran=Al-Johany'>عبدالله عواد الجهني</a> 
<a href='$wwwlink/index.php?Quran=maher'>ماهر المعيقلي</a>
<a href='$wwwlink/index.php?Quran=Al-Shuraim'>سعود الشريم</a>
<a href='$wwwlink/index.php?Quran=Al-Ghamdi'>سعد الغامدي</a>
<a href='$wwwlink/index.php?Quran=Fares'>فارس عباد</a>
<a href='$wwwlink/index.php?Quran=Alafasi'>مشاري العفاسي</a>
<a href='$wwwlink/index.php?Quran=abdulkafi'>خالد عبدالكافي</a>
<a href='$wwwlink/index.php?Quran=adel-rayan'>عادل ريان</a>
<a href='$wwwlink/index.php?Quran=Al-Ahmad'>عبدالعزيز الأحمد</a>
<a href='$wwwlink/index.php?Quran=alakhdar'>إبراهيم الأخضر</a><a href='$wwwlink/index.php?Quran=Al-Dosari'>ياسر الدوسري</a><a href='$wwwlink/index.php?Quran=Al-Hussary'>محمود خليل الحصري</a><a href='$wwwlink/index.php?Quran=Ali-Alhuthaifi'>علي الحذيفي</a><a href='$wwwlink/index.php?Quran=alkalbany'>عادل الكلباني</a><a href='$wwwlink/index.php?Quran=Al-Mattrod'>عبد الله المطرود</a><a href='$wwwlink/index.php?Quran=Al-Qahtani'>خالد القحطاني</a><a href='$wwwlink/index.php?Quran=al-qasim'>عبدالمحسن القاسم</a><a href='$wwwlink/index.php?Quran=Al-Qazabri'>عمر القزابري</a>
<a href='$wwwlink/index.php?Quran=athobaity'>عبدالبارئ الثبيتي</a>
<a href='$wwwlink/index.php?Quran=basfar'>عبدالله بصفر</a>
<a href='$wwwlink/index.php?Quran=Bukhatir'>صلاح بو خاطر</a>
<a href='$wwwlink/index.php?Quran=doukkali'>الدوكالي محمد العالم</a>
<a href='$wwwlink/index.php?Quran=el-najjar'>صلاح النجار</a>
<a href='$wwwlink/index.php?Quran=Hani'>هاني الرفاعي</a>
<a href='$wwwlink/index.php?Quran=hatem'>حاتم فريد الواعر</a>
<a href='$wwwlink/index.php?Quran=Jaber'>علي جابر</a>
<a href='$wwwlink/index.php?Quran=jamal'>جمال شاكر عبد الله</a>
<a href='$wwwlink/index.php?Quran=Jibrel'>محمد جبريل</a>
<a href='$wwwlink/index.php?Quran=Kanakeri'>عبدالهادي كناكري</a>
<a href='$wwwlink/index.php?Quran=khalifa'>خليفة الطنيجي</a>
<a href='$wwwlink/index.php?Quran=khayat'>عبدالله خياط</a>
<a href='$wwwlink/index.php?Quran=Mohamad-Abdullkarem'>محمد عبدالكريم</a>
<a href='$wwwlink/index.php?Quran=muslim'>عادل مسلم</a>
<a href='$wwwlink/index.php?Quran=nabil'>نبيل الرفاعي</a>
<a href='$wwwlink/index.php?Quran=Sahl-Yassin'>سهل ياسين</a>
<a href='$wwwlink/index.php?Quran=Salah-Albudair'>صلاح البدير</a>
<a href='$wwwlink/index.php?Quran=Shatri'>شيخ أبو بكر الشاطري</a>
<a href='$wwwlink/index.php?Quran=Shirazad-Taher'>شيرزاد طاهر</a>
<a href='$wwwlink/index.php?Quran=soufi'>عبدالرشيد بن علي صوفي</a>
<a href='$wwwlink/index.php?Quran=Tawfeeq-As-Sayegh'>توفيق الصايغ</a>
<a href='$wwwlink/index.php?Quran=yaseen'>ياسين</a>
<a href='$wwwlink/index.php?Quran=youssef'>يوسف الشويعي</a>
<a href='$wwwlink/index.php?Quran=zain'>الزين محمد أحمد</a>
<a href='$wwwlink/index.php?Quran=zaki'>زكي داغستاني</a>
<a href='$wwwlink/index.php?Quran=banr'>بنرات</a>
<a href='$wwwlink/alla7.php?sedany=1'>الله</a>
<a href='$wwwlink/alla7.php?sedany=2'>الرحمن الرحيم</a>
<a href='$wwwlink/alla7.php?sedany=3'>الملك</a>
<a href='$wwwlink/alla7.php?sedany=4'>القدوس</a>
<a href='$wwwlink/alla7.php?sedany=5'>السلام</a>
<a href='$wwwlink/alla7.php?sedany=6'>المؤمن</a>
<a href='$wwwlink/alla7.php?sedany=7'>المهيمن</a>
<a href='$wwwlink/alla7.php?sedany=8'>العزيز</a>
<a href='$wwwlink/alla7.php?sedany=9'>الجبار</a>
<a href='$wwwlink/alla7.php?sedany=10'>المتكبر</a>
<a href='$wwwlink/alla7.php?sedany=11'>الخالق</a>
<a href='$wwwlink/alla7.php?sedany=12'>البارئ</a>
<a href='$wwwlink/alla7.php?sedany=13'>المصور</a>
<a href='$wwwlink/alla7.php?sedany=14'>الغفار</a>
<a href='$wwwlink/alla7.php?sedany=15'>القهار</a>
<a href='$wwwlink/alla7.php?sedany=16'>الوهاب</a>
<a href='$wwwlink/alla7.php?sedany=17'>الرزاق</a>
<a href='$wwwlink/alla7.php?sedany=18'>الفتاح</a>
<a href='$wwwlink/alla7.php?sedany=19'>العليم</a>
<a href='$wwwlink/alla7.php?sedany=20'>القابض</a>
<a href='$wwwlink/alla7.php?sedany=21'>الباسط</a>
<a href='$wwwlink/alla7.php?sedany=22'>الخافض</a>
<a href='$wwwlink/alla7.php?sedany=23'>الرافع</a>
<a href='$wwwlink/alla7.php?sedany=24'>المعز</a>
<a href='$wwwlink/alla7.php?sedany=25'>المذل</a>
<a href='$wwwlink/alla7.php?sedany=26'>السميع</a>
<a href='$wwwlink/alla7.php?sedany=27'>البصير </a>
<a href='$wwwlink/alla7.php?sedany=28'>الحكم</a>
<a href='$wwwlink/alla7.php?sedany=29'>العدل</a>
<a href='$wwwlink/alla7.php?sedany=30'>اللطيف</a>
<a href='$wwwlink/alla7.php?sedany=31'>الخبير</a>
<a href='$wwwlink/alla7.php?sedany=32'>الحليم </a>
<a href='$wwwlink/alla7.php?sedany=33'>العظيم</a>
<a href='$wwwlink/alla7.php?sedany=34'>الغفور</a>
<a href='$wwwlink/alla7.php?sedany=35'>الشكور</a>
<a href='$wwwlink/alla7.php?sedany=36'>العـلي</a>
<a href='$wwwlink/alla7.php?sedany=37'>الكبير</a>
<a href='$wwwlink/alla7.php?sedany=38'>الحفيظ</a>
<a href='$wwwlink/alla7.php?sedany=39'>المقيت</a>
<a href='$wwwlink/alla7.php?sedany=40'>الحسيب </a>
<a href='$wwwlink/alla7.php?sedany=41'>الجليل</a>
<a href='$wwwlink/alla7.php?sedany=42'>الكريم</a>
<a href='$wwwlink/alla7.php?sedany=43'>الرقيب</a>
<a href='$wwwlink/alla7.php?sedany=44'>المجيب </a>
<a href='$wwwlink/alla7.php?sedany=45'>الواسع</a>
<a href='$wwwlink/alla7.php?sedany=46'>الحكيم</a>
<a href='$wwwlink/alla7.php?sedany=47'>الودود </a>
<a href='$wwwlink/alla7.php?sedany=48'>المجيد</a>
<a href='$wwwlink/alla7.php?sedany=49'>الباعث</a>
<a href='$wwwlink/alla7.php?sedany=50'>الشهيد</a>
<a href='$wwwlink/alla7.php?sedany=51'>الحـق</a>
<a href='$wwwlink/alla7.php?sedany=52'>الوكيل</a>
<a href='$wwwlink/alla7.php?sedany=53'>القوي  المتين</a>
<a href='$wwwlink/alla7.php?sedany=54'>الولـي </a>
<a href='$wwwlink/alla7.php?sedany=55'>الحميد</a>
<a href='$wwwlink/alla7.php?sedany=56'>المحصي</a >
<a href='$wwwlink/alla7.php?sedany=57'>المبدئ</a>
<a href='$wwwlink/alla7.php?sedany=58'>المعيد</a>
<a href='$wwwlink/alla7.php?sedany=59'>المحيي</a>
<a href='$wwwlink/alla7.php?sedany=60'>المميت </a>
<a href='$wwwlink/alla7.php?sedany=61'>الحـي</a>
<a href='$wwwlink/alla7.php?sedany=62'>القيوم </a>
<a href='$wwwlink/alla7.php?sedany=63'>الواجد</a>
<a href='$wwwlink/alla7.php?sedany=64'>الماجد </a>
<a href='$wwwlink/alla7.php?sedany=65'>الواحد </a>
<a href='$wwwlink/alla7.php?sedany=66'>الصمد</a>
<a href='$wwwlink/alla7.php?sedany=67'>القادر المقتدر </a>
<a href='$wwwlink/alla7.php?sedany=68'>المقدم المؤخر</a>
<a href='$wwwlink/alla7.php?sedany=69'>الأول  الآخر </a>
<a href='$wwwlink/alla7.php?sedany=70'>الظاهر  الباطن </a>
<a href='$wwwlink/alla7.php?sedany=71'>الوالـي </a>
<a href='$wwwlink/alla7.php?sedany=72'>المتعالي </a>
<a href='$wwwlink/alla7.php?sedany=73'>البر</a>
<a href='$wwwlink/alla7.php?sedany=74'>التواب</a>
<a href='$wwwlink/alla7.php?sedany=75'>المنتقم </a>
<a href='$wwwlink/alla7.php?sedany=76'>العفو</a>
<a href='$wwwlink/alla7.php?sedany=77'>الرؤوف </a>
<a href='$wwwlink/alla7.php?sedany=78'>مالك الملك </a>
<a href='$wwwlink/alla7.php?sedany=79'>ذو الجلال والإكرام</a>
<a href='$wwwlink/alla7.php?sedany=80'>المقسط </a>
<a href='$wwwlink/alla7.php?sedany=81'>الجامع</a>
<a href='$wwwlink/alla7.php?sedany=82'>الغني</a>
<a href='$wwwlink/alla7.php?sedany=83'>المغني </a>
<a href='$wwwlink/alla7.php?sedany=84'>المانع </a>
<a href='$wwwlink/alla7.php?sedany=85'>الضار  النافع</a>
<a href='$wwwlink/alla7.php?sedany=86'>النور</a>
<a href='$wwwlink/alla7.php?sedany=87'>الهادئ</a>
<a href='$wwwlink/alla7.php?sedany=88'>البديع</a>
<a href='$wwwlink/alla7.php?sedany=89'>الباقي </a>
<a href='$wwwlink/alla7.php?sedany=90'>الوراث </a>
<a href='$wwwlink/alla7.php?sedany=91'>الرشيد </a>
<a href='$wwwlink/alla7.php?sedany=92'>الصبور </a>
<a href='$wwwlink/Do3a.php?sedany=Do3am1'>الأدعية ا مجموعة (1) </a>
<a href='$wwwlink/Do3a.php?sedany=Do3am2'>الأدعية ا مجموعة (2) </a>
<a href='$wwwlink/Do3a.php?sedany=Do3am3'>الأدعية ا مجموعة (3) </a>
<a href='$wwwlink/Do3a.php?sedany=Do3am4'>الأدعية ا مجموعة (4) </a>
<a href='$wwwlink/Do3a.php?sedany=Do3am5'>الأدعية ا مجموعة (5) </a>
<a href='$wwwlink/Do3a.php?sedany=Do3am6'>الأدعية ا مجموعة (6) </a>
<a href='$wwwlink/Do3a.php?sedany=Do3am7'>الأدعية ا مجموعة (7) </a>
<a href='$wwwlink/Do3a.php?sedany=Do3am8'>الأدعية ا مجموعة (8) </a>
<a href='$wwwlink/Do3a.php?sedany=Do3a1'>فضل الدعاء </a>
<a href='$wwwlink/Do3a.php?sedany=Do3a2'>ادعية من القرآن الكريم</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a3'>اذكار الصباح والمساء </a>
<a href='$wwwlink/Do3a.php?sedany=Do3a4'>الدعاء قبل النوم وعند الاستيقاظ</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a5'>دعاء لبس الثوب</a> 
<a href='$wwwlink/Do3a.php?sedany=Do3a6'>دعاء لبس الثوب الجديد او النعل ونحوه</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a7'>الدعاء لمن لبس ثوبا جديداً </a> 
<a href='$wwwlink/Do3a.php?sedany=Do3a8'>الدعاء عند التعجب</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a9'>الدعاء عند دخول الخلاء عند الخروج منه</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a10'>الدعاء عند سماع الاذان</a>
<a href='$wwwlink/files.php?sedany=files1'> فلاش  أجمل عروس</a>
<a href='$wwwlink/files.php?sedany=files2'> فلاش أناشيد حبك لنا ملموس</a>
<a href='$wwwlink/files.php?sedany=files3'> فلاش قبـل الندم </a>
<a href='$wwwlink/files.php?sedany=files4'> فلاش أناشيد أحبكم يامهجتي</a>
<a href='$wwwlink/files.php?sedany=files5'> فلاش الحـــيــاهـ الطيـبه</a>
<a href='$wwwlink/files.php?sedany=files6'> فلاش آهــــات</a>
<a href='$wwwlink/files.php?sedany=files7'> فلاش  القلب الحزين</a>
<a href='$wwwlink/files.php?sedany=files8'> فلاش  رنة جوال</a>
<a href='$wwwlink/files.php?sedany=files9'> فلاش الــقدر</a>
<a href='$wwwlink/files.php?sedany=files10'> فلاش  أناشيد أمي</a>
<a href='$wwwlink/files.php?sedany=files11'> فلاش انعم الله علين</a>
<a href='$wwwlink/files.php?sedany=files12'> فلاش  أنت الأمان</a>
<a href='$wwwlink/files.php?sedany=files13'> فلاش أنتي العفيفة</a>
<a href='$wwwlink/files.php?sedany=files14'> فلاش  اسمعيني يا اخيه </a>
<a href='$wwwlink/files.php?sedany=files15'> فلاش أتمناها</a>
<a href='$wwwlink/files.php?sedany=files16'> فلاش  درر باز الشبخ عبدالعزيز بن عبدالله بن باز الله يرحهم</a>
<a href='$wwwlink/files.php?sedany=files17'> فلاش  أناشيد دار المسنين </a> 
<a href='$wwwlink/files.php?sedany=files18'> فلاش  أناشيد بلادي</a>
<a href='$wwwlink/files.php?sedany=files19'> فلاش أناشيد ياشباب الدرب</a>
<a href='$wwwlink/files.php?sedany=files20'> فلاش  ينادي فؤادي</a>
<a href='$wwwlink/files.php?sedany=files21'> فلاش فضائل صورة البقره</a>
<a href='$wwwlink/files.php?sedany=files22'>  فرشي التراب يضمني   </a>
<a href='$wwwlink/files.php?sedany=files23'> فلاش فرشي التراب يضمني </a>
<a href='$wwwlink/files.php?sedany=files24'> فلاش  أناشيد جيتك يادار العز </a>
<a href='$wwwlink/files.php?sedany=files25'> فلاش ياغــا فـــلاً</a>
<a href='$wwwlink/files.php?sedany=files26'> فلاش هذا الحبييب</a>
<a href='$wwwlink/files.php?sedany=files27'> فلاش هـــداية غريبة </a>
<a href='$wwwlink/files.php?sedany=files28'> فلاش هو الله</a>
<a href='$wwwlink/files.php?sedany=files29'> فلاش  خالد يبي شوربه </a>
<a href='$wwwlink/files.php?sedany=files30'> فلاش  كريسماس</a>
<a href='$wwwlink/files.php?sedany=files31'> فلاش  أناشيد لاح النور </a>
<a href='$wwwlink/files.php?sedany=files32'> فلاش  لا تحزن </a>
<a href='$wwwlink/files.php?sedany=files33'> فلاش  اللـؤلـؤة المصونـة</a>
<a href='$wwwlink/files.php?sedany=files34'> فلاش  أناشيد مع الله </a>
<a href='$wwwlink/files.php?sedany=files35'> فلاش  ما أغلاك </a>
<a href='$wwwlink/files.php?sedany=files36'> فلاش   ما أرحمك يا أماهـ </a>
<a href='$wwwlink/files.php?sedany=files37'> فلاش  المملكه وطنا</a>
<a href='$wwwlink/files.php?sedany=files38'> فلاش  من يدعوني  </a>
<a href='$wwwlink/files.php?sedany=files39'> فلاش  محمد رسول الله ( صلى الله عليه وسلم )محمد رسول الله  فلاش   </a>
<a href='$wwwlink/files.php?sedany=files40'> فلاش  اناشيد مشاعر مودعة</a>
<a href='$wwwlink/files.php?sedany=files41'> فلاش  نهائة رائد  </a>
<a href='$wwwlink/files.php?sedany=files42'> فلاش  رحمة للعالمين</a>
<a href='$wwwlink/files.php?sedany=files43'> فلاش  رنة جوال</a>
<a href='$wwwlink/files.php?sedany=files44'> فلاش رقــة قــلــب</a>
<a href='$wwwlink/files.php?sedany=files45'> فلاش سامحوووني</a>
<a href='$wwwlink/files.php?sedany=files46'> فلاش  أناشيد طلت ياليل</a>
<a href='$wwwlink/files.php?sedany=files47'> فلاش طفل الأحداث</a>
<a href='$wwwlink/files.php?sedany=files48'> فلاش  أناشيد طيور الأنسي غني </a>
<a href='$wwwlink/files.php?sedany=files49'> فلاش  ضحكة زماني</a>
<a href='$wwwlink/files.php?sedany=files50'> فلاش توبتي</a>
<a href='$wwwlink/files.php?sedany=files51'> فلاش طفل الأحداث</a>
<a href='$wwwlink/files.php?sedany=files52'> فلاش ولد النور</a>
<a href='$wwwlink/files.php?sedany=files53'> فلاش  وبالوالدين إحسان</a>
<a href='$wwwlink/files.php?sedany=files54'> فلاش  أناشيد وقفت أناجي </a>
<a href='$wwwlink/files.php?sedany=files55'> فلاش  يحبهم ويحبونه</a>
<a href='$wwwlink/vg.php?sedany=vgm1'>إسلام  ا مجموعة (1) </a>
<a href='$wwwlink/vg.php?sedany=vgm2'>إسلام  ا مجموعة (2) </a>
<a href='$wwwlink/vg.php?sedany=vgm3'>إسلام  ا مجموعة (3) </a>
<a href='$wwwlink/vg.php?sedany=vgm4'>إسلام  ا مجموعة (4) </a>
<a href='$wwwlink/vg.php?sedany=vgm5'>إسلام  ا مجموعة (5) </a>
<a href='$wwwlink/vg.php?sedany=vgm6'>إسلام  ا مجموعة (6) </a>
<a href='$wwwlink/vg.php?sedany=vgm7'>إسلام  ا مجموعة (7) </a>
<a href='$wwwlink/vg.php?sedany=vgm8'>إسلام  ا مجموعة (8) </a>
<a href='$wwwlink/vg.php?sedany=vgm9'>إسلام  ا مجموعة (9) </a>
<a href='$wwwlink/vg.php?sedany=vgm10'>إسلام  ا مجموعة (10) </a>
<a href='$wwwlink/vg.php?sedany=vgm11'>إسلام  ا مجموعة (11) </a>
<a href='$wwwlink/vg.php?sedany=vgm12'>إسلام  ا مجموعة (12) </a>
<a href='$wwwlink/vg.php?sedany=vgm13'>إسلام  ا مجموعة (13) </a>
<a href='$wwwlink/vg.php?sedany=vg1'>المغني الأنجليزي سابقاًَ يوسف إسلام يوسف</a>
<a href='$wwwlink/vg.php?sedany=vg2'>الجراح الفرنسي موريس بوكاي</a>
<a href='$wwwlink/vg.php?sedany=vg3'>الدكتور الفرنسي علي سلمان بنو</a>
<a href='$wwwlink/vg.php?sedany=vg4'>أستاذ الرياضيات الكندي جاري ميلر</a>
<a href='$wwwlink/vg.php?sedany=vg5'>أستاذ الفيزياء عضو الأكاديمية الطبية الروسية وكيث مور عالم الأجنة الشهير</a>
<a href='$wwwlink/vg.php?sedany=vg6'>أستاذ التشريح تاجاثاث وعالم الجيولوجيا  ألفريد كرونير</a>
<a href='$wwwlink/vg.php?sedany=vg7'>سليل الأسرة المالكة في بريطانيا يجد ملاذه في الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg8'>اسلام روبرت كرين مستشار</a>
<a href='$wwwlink/vg.php?sedany=vg9'>أستاذ اللاهوت السابق إبراهيم خليل فلوبوس</a>
<a href='$wwwlink/vg.php?sedany=vg10'>قصة إسلام القس المصري إسحاق هلال مسيحه</a>
<a href='$wwwlink/vg.php?sedany=vg11'>الفتى النصراني المصري الذي هداه الله إلى الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg12'>الشماس المصري الدكتور وديع أحمد</a>
<a href='$wwwlink/vg.php?sedany=vg13'>اهتداء عالم الاجتماع الإنجليزي حسين روف</a>
<a href='$wwwlink/vg.php?sedany=vg14'>المفكر الإنجليزي مارتن لنجز وقصة انتقاله إلى النور</a>
<a href='$wwwlink/vg.php?sedany=vg15'>مايكل وُلفي سيكتر .. كاتب أميركي من أم مسيحية وأب يهودي يعتنق الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg16'>القسيس السابق بنيامين كلداني عبد الأحد داود</a>
<a href='$wwwlink/vg.php?sedany=vg17'>السفير الألماني في المغرب سابقاً د.مراد هوفمان</a>
<a href='$wwwlink/vg.php?sedany=vg18'>الطفل الأمريكي فريتزأسلم وهو في الثامنة</a>
<a href='$wwwlink/vg.php?sedany=vg19'>القسيس الامريكي الشهير الذي أسلم عند مشاهدته لأحمد ديدات</a>
<a href='$wwwlink/vg.php?sedany=vg20'>إسلام الدكتورالعالم والصحفي والمؤلف الألماني حامد ماركوس</a>
<a href='$wwwlink/vg.php?sedany=vg21'>لاعب السلة الأمريكي محمود عبدالرؤوف ولاعب كرة القدم الفرنسي أنيلك</a>
<a href='$wwwlink/vg.php?sedany=vg22'>داود موسى بيتكوك أسلم بسبب سورة القمر</a>
<a href='$wwwlink/vg.php?sedany=vg23'>قصة إسلام ثاني أكبر قسيس في غان</a>
<a href='$wwwlink/vg.php?sedany=vg24'>إسلام رئيس جمهورية جامبيا وموسي زعيم قبائل الزولو</a>
<a href='$wwwlink/vg.php?sedany=vg25'>سلطان تشادي كان نصرانياً متعصباً وصار من أبرز الدعاة</a>
<a href='$wwwlink/vg.php?sedany=vg26'>هلوجارد السويسرية بعد إشهار إسلامها:النصرانية شىء هامشى فى الغرب</a>
<a href='$wwwlink/vg.php?sedany=vg27'>أفرينا الأوكرانية بحثت عن الأمن والسلام .. فوجدته في الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg28'>مريتا السويدية بعد إسلامها:الهجوم على الإسلام لغة سائدة فى الغرب</a>
<a href='$wwwlink/vg.php?sedany=vg29'>توبة عارضتي الأزياء الفرنسية فابيان واليونانية ماكلين سيكاروس</a>
<a href='$wwwlink/vg.php?sedany=vg30'>راندا نيقوسيان الدانماركية أسلمت بسبب أية</a>
<a href='$wwwlink/vg.php?sedany=vg31'>الداعية البريطانية سارة جوزيف</a>
<a href='$wwwlink/vg.php?sedany=vg32'>إمرأة بريطانية كاثوليكية تعلن إسلامها بعد حوار طويل للأديان</a>
<a href='$wwwlink/vg.php?sedany=vg33'>معلمة اللاهوت ميري واتسون بعد إسلامه</a>
<a href='$wwwlink/vg.php?sedany=vg34'>أميرة الأمريكية تقول لن أترك الإسلام مهما فعل أهلي ووطني</a>
<a href='$wwwlink/vg.php?sedany=vg35'>قصة إسلام خديجة (نيرس داني سابقاً</a>
<a href='$wwwlink/vg.php?sedany=vg36'>كاثي الأمريكية أسلمت بنسخة من ترجمة معاني القرآن</a>
<a href='$wwwlink/vg.php?sedany=vg37'>سارة الأمريكية مسلمة بعد دراسة 12 ديانة!!</a>
<a href='$wwwlink/vg.php?sedany=vg38'>سارة أمريكية أسلمت وعمرها 14 عاماً وعائشة أسلمت وعمرها 12 عاماً</a>
<a href='$wwwlink/vg.php?sedany=vg39'>الفتاة الأمريكيةالتي كانت تكره الإسلام وتعدد الزوجات</a>
<a href='$wwwlink/vg.php?sedany=vg40'>سناء وسوسن هندي المصريتان من الظلمات إلي النور</a>
<a href='$wwwlink/vg.php?sedany=vg41'>الفتاة الكندية جينيفر وطبيبة الأسنان المكسيكية تريست</a>
<a href='$wwwlink/vg.php?sedany=vg42'>أخت خليجية أسلمت حديثاً</a>
<a href='$wwwlink/vg.php?sedany=vg43'>مضيفة الطيران الأسترالية تنقلت من دين إلى آخر ولم تجد ضالتها إلا فيالإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg44'>قصة إسلام الأخوة المصريين الثلاثة</a>
<a href='$wwwlink/vg.php?sedany=vg45'>الموسيقي البريطاني براين هوايت يهجر الموسيقى والخمر ويلجأ إلى الله مسلماً</a>
<a href='$wwwlink/vg.php?sedany=vg46'>إسلام الممثل الأمريكي ويل سميث والممثل الإيطالي جينو لو كابوتو</a>
<a href='$wwwlink/vg.php?sedany=vg47'>شقيق مايكل جاكسون: إشهار إسلامي في السعودية فاجأ أفراد أسرتي بأميرك</a>
<a href='$wwwlink/vg.php?sedany=vg48'>الدجاج كسر آلهتن</a>
<a href='$wwwlink/vg.php?sedany=vg49'>خالد وانج</a>
<a href='$wwwlink/vg.php?sedany=vg50'>رحلة رجلان بين أربع ديانات !!</a>
<a href='$wwwlink/vg.php?sedany=vg51'>قصة إسلام الأخت الأمريكية كايسي ستاربَك</a>
<a href='$wwwlink/vg.php?sedany=vg52'>المؤلف والروائي والشاعرالبريطاني ويليام بيكارد</a>
<a href='$wwwlink/vg.php?sedany=vg53'>قصة إسلام الأمريكية جهادة</a>
<a href='$wwwlink/vg.php?sedany=vg54'>رئيس الأساقفة اللوثريِّ التنزانيِّ (سابقاً)أبو بكر موايبيو</a>
<a href='$wwwlink/vg.php?sedany=vg55'>الأخ أحمد كوربس من الفلبين (الراهب ماركو كوربس سابقاً</a>
<a href='$wwwlink/vg.php?sedany=vg56'>قصة اسلام الرسام والمفكر الفرنسي المعروف اتييان دينيه</a>
<a href='$wwwlink/vg.php?sedany=vg57'>محمد اقبال من السيخية إلي الإسلام ومريم الأسترالية من البهائية إلي الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg58'>ايريس صفوت الألمانية بعد إسلامها: وجدت في الإسلام تكريما افتقدته في الغرب</a>
<a href='$wwwlink/vg.php?sedany=vg59'>العالم المجرّي عبدالكريم جرمانيوس الذي عشق الإسلام والشرق</a>
<a href='$wwwlink/vg.php?sedany=vg60'>مدير دريم بارك الأمريكي يعلن اسلامه</a>
<a href='$wwwlink/vg.php?sedany=vg61'>القُمُّص المصري عزت إسحاق معوَّض الذي صار داعية مسلم</a>
<a href='$wwwlink/vg.php?sedany=vg62'>إكتشاف الاسلام ونقد المسيحية في تجربة الباحثة الامريكية بربارا براون </a>
<a href='$wwwlink/vg.php?sedany=vg63'>الأمريكية ديانا بيتي قصة العودة للمنزل</a>
<a href='$wwwlink/vg.php?sedany=vg64'>من اليهودية إلى الاسلام، قصة يوسف كوهينالقدس</a>
<a href='$wwwlink/vg.php?sedany=vg65'>يوسف استس الأمريكي من قسيس إلي داعية</a>
<a href='$wwwlink/vg.php?sedany=vg66'>القس المصري فوزي صبحي سمعان أصبح معلماً للدين الإسلامي</a>
<a href='$wwwlink/vg.php?sedany=vg67'>القس الفليبيني عيسي بياجو</a>
<a href='$wwwlink/vg.php?sedany=vg68'>كان أبي قسيسا .. وأسلم</a>
<a href='$wwwlink/vg.php?sedany=vg69'>الدكتورة الروسية آلا أولينيكوفا: كانت حياتنا جحيما مستعر</a>
<a href='$wwwlink/vg.php?sedany=vg70'>جولينا بعد إسلامها:فروق عظيمة بين ماكنت عليه وماصرت اليه</a>
<a href='$wwwlink/vg.php?sedany=vg71'>الأمريكية هدي دورج:لم تكن اجاباتهم شافية</a>
<a href='$wwwlink/vg.php?sedany=vg72'>من التحامل علي نبي الإسلام إلي البكاء عند قبره</a>
<a href='$wwwlink/vg.php?sedany=vg73'>الفرنسي فانسان مونتييه الذي صار مفكراً إسلامياً</a>
<a href='$wwwlink/vg.php?sedany=vg74'>محمّد أسد (ليوبولد فايس).. التحوّل الشامل الى الاسلام</a>
<a href='$wwwlink/vg.php?sedany=vg75'>قصة إسلام أفراح الشيباني</a>
<a href='$wwwlink/vg.php?sedany=vg76'>القس المنضبط دوشمان يعثر علي مأوي روحه في الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg77'>رئيس المعهد الدولي التكنولوجي شاهين يعلن إسلامه في الرياض</a>
<a href='$wwwlink/vg.php?sedany=vg78'>المغنية كريستيان باكر</a>
<a href='$wwwlink/vg.php?sedany=vg79'>حجاب أمريكية السبب في إسلام الأستاذ الجامعي أكوياكان</a>
<a href='$wwwlink/vg.php?sedany=vg80'>أستاذ الرياضيات الأمريكي جيفري لانج و أول صلاة</a>
<a href='$wwwlink/vg.php?sedany=vg81'>القس الأثيوبي ملقاه قفادو الذي أصبح داعية للإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg82'>المُنَصِّر المتعصب الذي تعصب للإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg83'>سيف الإسلام التهامي يروي قصة إسلامه</a>
<a href='$wwwlink/vg.php?sedany=vg84'>معلم النصرانيةالسريلانكي ألدو دمريس  الذي صار داعية للإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg85'>مبشرة مسيحية ألمانية تعتنق الإسلام بالعراق</a>
<a href='$wwwlink/vg.php?sedany=vg86'>الحسناء الأوكرانية تعتنق الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg87'>ابن القسيس الذي اسلم</a>
<a href='$wwwlink/vg.php?sedany=vg88'>إسلام بطل السنوكر العالمي السابق</a>
<a href='$wwwlink/vg.php?sedany=vg89'>بوريس الأوكراني ومشاعره في أول يوم يعتنق فيه الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg90'>ماثيو ونيكولاس: نتوقع ان يهيمن الإسلام في أوروبا خلال 30 عام</a>
<a href='$wwwlink/vg.php?sedany=vg91'>اللورد برنتون صب جل إهتمامه على التنصير وإنتهى به المطاف الى نور الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg92'>إيفا ماريا الألمانية:صورة المعبود عند النصارى قريبة جداً منا معشر البشر</a>
<a href='$wwwlink/vg.php?sedany=vg93'>كرست راجا عالم النصرانية الهندي</a>
<a href='$wwwlink/vg.php?sedany=vg94'>عثمان عبد الله بريشا بنكمرت من البوذية إلي الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg95'>دخلت إلى المسجد يهودية وخرجت منه مسلمة</a>
<a href='$wwwlink/vg.php?sedany=vg96'>عمر جونسون .. من تكساس إلى الإسكندرية </a>
<a href='$wwwlink/vg.php?sedany=vg97'>معطيات القرآن حـول النوم والموت في تجربة العالم البريطاني آرثر أليسون</a>
<a href='$wwwlink/vg.php?sedany=vg98'>الكولونيل دونالدس روكويل: يقين المسلمين السبب</a>
<a href='$wwwlink/vg.php?sedany=vg99'>حكاية إهتداء المفكر السويسري  روجيه دوباكييه</a>
<a href='$wwwlink/vg.php?sedany=vg100'>وحدانية الله</a>
<a href='$wwwlink/vg.php?sedany=vg101'>هل إنتشر الإسلام بحد السيف</a>
<a href='$wwwlink/vg.php?sedany=vg102'>كتاب الجانب الخفي وراء إسلام هؤلاء محمد كامل عبدالصمد</a>
<a href='$wwwlink/vg.php?sedany=vg103'>مناظرة من 20 سؤالبسم الله الرحمن الرحيم </a>
<a href='$wwwlink/vg.php?sedany=vg104'>أصغر رسالة في نقض النصرانية </a>
<a href='$wwwlink/vg.php?sedany=vg105'>أخبرنا الله تعالى أن نبي الله عيسى بشر بمبعث محمد صلى الله عليه وسلم </a>
<a href='$wwwlink/vg.php?sedany=vg106'>;نساء من الغرب يعتنقن الإسلام بقلم د.عبد المعطي الدالاتي</a>
<a href='$wwwlink/vg.php?sedany=vg107'>أي الثلاثة كلام الله ؟(التوراة-الإنجيل-القرآن)</a>
<a href='$wwwlink/vg.php?sedany=vg108'>مقارنة سريعة بين آيات القرآن وكلام الكتاب المقدس</a>
<a href='$wwwlink/vg.php?sedany=vg109'>و..أسلم كل من كان في الكنيسة</a>
<a href='$wwwlink/vg.php?sedany=vg110'>القرآن الكريم أكثر ما يدخل الناس في الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg111'>الدعوة إلي الدين الحق </a>
<a href='$wwwlink/vg.php?sedany=vg112'>الحياة الدنيوية لمريم ابنة عمران وابنها عيسى عليهما السلام</a>
<a href='$wwwlink/vg.php?sedany=vg113'>الخمر بين الإسلام والنصرانية بقلم أحمد ديدات</a>
<a href='$wwwlink/vg.php?sedany=vg114'>المسـتقبل للإســـلام</a>
<a href='$wwwlink/vg.php?sedany=vg115'>أصغر رسالة في نقض النصرانية</a>
<a href='$wwwlink/vg.php?sedany=vg116'>الشيخ محمد صالح المنجد يرد علي تساؤلات طالبة نصرانية</a>
<a href='$wwwlink/vg.php?sedany=vg117'>اعتراف عظيم أقباط مصر بالرسول عليه الصلاة والسلام</a>
<a href='$wwwlink/vg.php?sedany=vg118'>الطلاق بين الإسلام والنصرانية واليهودية</a>
<a href='$wwwlink/vg.php?sedany=vg119'>حكمة إباحة تعدد الزوجات</a>
<a href='$wwwlink/vg.php?sedany=vg120'>رد الشبهات عن القرآن الكريم</a>
<a href='$wwwlink/vg.php?sedany=vg121'>حوار بين مسلم ونصراني</a>
<a href='$wwwlink/vg.php?sedany=vg122'>شهادات علماء الغرب بالاعجاز العلمي في القرآن الكريم</a>
<a href='$wwwlink/vg.php?sedany=vg123'>شهادات الأعلام الذين دخلوا في الإسلام</a>
<a href='$wwwlink/vg.php?sedany=vg124'>رعب اليهود من انتشار الإسلام في أوروبا وأمريك</a>
<a href='$wwwlink/vg.php?sedany=vg125'>قصص فرنسيين اهتدوا للإسلام </a>
<a href='$wwwlink/vg.php?sedany=vg126'>كتاب هكذا أسلمنا بقلم د.عبدالمعطي الدالاتي</a>
<a href='$wwwlink/vip.php?sedany=vip1'>آدم عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip2'>إدريس عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip3'>نوح عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip4'>هود عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip5'>صالح عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip6'>إبراهيم عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip7'>لوط عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip8'>إسماعيل عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip9'>إسحاق عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip10'>يعقوب عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip11'>يوسف عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip12'>أيوب عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip13'>ذو الكفل عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip14'>يونس  عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip15'>شعيب عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip16'>موسى وهارون عليهما السلام</a>  <a href='$wwwlink/vip.php?sedany=vip17'>إلياس عليه السلام</a><a href='$wwwlink/vip.php?sedany=vip18'>اليسع  عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip19'>داود عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip20'>سليمان عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip21'>زكريا عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip22'>يحيى عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip23'>عيسى عليه السلام</a>
<a href='$wwwlink/vip.php?sedany=vip24'>محمد صلى الله عليه وسلم</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a11'>الدعاء بعد الوضوء</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a12'>الدعاء عند الذهاب الى المسجد</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a13'>الدعاء عند دخول المسجد</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a14'>الدعاء عند الخروج من المسجد</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a15'>دعاء الاستفتاح</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a16'>الدعاء في السجود</a> 
<a href='$wwwlink/Do3a.php?sedany=Do3a17'>دعاء مابين التشهد والتسليم</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a18'>دعاء القنوت </a>
<a href='$wwwlink/Do3a.php?sedany=Do3a19'>دعاء سجود التلاوة </a>
<a href='$wwwlink/Do3a.php?sedany=Do3a20'>كيفية الصلاة على النبي صلى الله عليه وسلم</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a21'>سيد الاستغفار</a>  
<a href='$wwwlink/Do3a.php?sedany=Do3a22'>اذكار بعد الصلاة</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a23'>دعاء الدخول الى المنزل</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a24'>دعاء الخروج من المنزل</a> 
<a href='$wwwlink/Do3a.php?sedany=Do3a25'>الدعاء عند بداية الطعام وبعد الفراغ منه</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a26'>دعاء اللغو في الحديث (كفارة المجلس )</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a27'>دعاء الكرب</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a28'>الدعاء عند الهم والحزن</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a29'>دعاء المظلوم</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a30'>الدعاء عند الغضب</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a31'>دعاء من استصعب عليه امر م</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a32'>الدعاء لمن عرض عليك ماله</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a33'>دعاء من اثقلته الديون</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a34'>الدعاء عند إرجاع الدين ( القرض )</a> 
<a href='$wwwlink/Do3a.php?sedany=Do3a35'>الدعاء لمن صنع لك معروفاً</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a36'>الدعاء عند دخول السوق وعند الخروج منه</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a37'>دعاء السفر</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a38'>الدعاء للمسافر</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a39'>الدعاء عند الرجوع من السفر</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a40'>دعاء من نزل منزلاً</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a41'>الدعاء عند التطير</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a42'>دعاء الخوف</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a43'>دعاء الخوف من عدو ونحوه</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a44'>الدعاء عند لقاء العدو</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a45'>دعاء الاستسقاء</a> 
<a href='$wwwlink/Do3a.php?sedany=Do3a46'>الدعاء عند هيجان الريح</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a47'>الدعاء عند سماع الرعد</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a48'>الدعاء عند وبعد نزول المطر</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a49'>دعاء اذا كثر المطر وخيف منه الضرر</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a50'>الدعاء عند رؤية الهلال</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a51'>دعاء الصائم عند الإفطار</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a52'>دعاء المدعو او الضيف لصاحب الطعام</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a53'>دعاء ليلة القدر</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a54'>الدعاء عند الذبح والنحر</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a55'>دعاء الاضحية</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a56'>دعاء الاستخاره</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a57'>الدعاء للمتزوج</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a58'>دعاء الزوج في ليلة الزفاف</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a59'>دعاء الوطر(يقال قبل جماع الرجل لزوجته)</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a60'>الدعاء للمولود عند تحنيكه</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a61'>ادعية الرقيه</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a62'>دعاء من احس بوجع في جسده</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a63'>دعاء المريض</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a64'>دعاء عيادة المريض</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a65'>الدعاء عند رؤية مبتلى</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a66'>دعاء من ايس من حياته</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a67'>دعاء من يصارع سكرات الموت</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a68'>الدعاء عند نزول المصيبة</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a69'>الدعاء عند تغميض الميت</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a70'>دعاء من مات له ميت</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a71'>الدعاء للميت في الصلاة عليه</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a72'>الدعاء للفرط في الصلاة عليه</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a73'>دعاء التعزية</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a74'>الدعاء عند المرور بالقبور او زيارته</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a75'>ادعية جامعه نافعه بإذن الله , من دعاء الرسول عليه الصلاة والسلام</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a76'>من شروط وآداب الدعاء وأسباب الإجابة</a>
<a href='$wwwlink/Do3a.php?sedany=Do3a77'>أوقات وأحوال واماكن وأوضاع يستحب فيها الدعاء</a><div id='footer'>
<a target='_blank' href='$wwwlink'>  Powered by sedany.com   </a>
</div>
</div></body>
</html>";
echo $rss;
?>
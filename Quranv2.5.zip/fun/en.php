<?php
$LANGUAGE[1] = '1- Al-Fatiha';
$LANGUAGE[2] = "2- Al-Baqara";
$LANGUAGE[3] = "3- Al-i'Imran";
$LANGUAGE[4] = "4- An-Nisaa";
$LANGUAGE[5] = "5- Al-Maidah";
$LANGUAGE[6] = "6- Al-An'am";
$LANGUAGE[7] = "7- Al-A'raf";
$LANGUAGE[8] = "8- Al-Anfal";
$LANGUAGE[9] = "9- At-Tauba";
$LANGUAGE[10] = "10- Yunus";
$LANGUAGE[11] = "11- Hud ";
$LANGUAGE[12] = "12- Yusuf";
$LANGUAGE[13] = "13- Ar-Ra'd";
$LANGUAGE[14] = "14- Ibrahim";
$LANGUAGE[15] = "15- Al-Hijr";
$LANGUAGE[16] = "16- An-Nahl";
$LANGUAGE[17] = "17- Al-Isra";
$LANGUAGE[18] = "18- Al-Kahf";
$LANGUAGE[19] = "19- Maryam ";
$LANGUAGE[20] = "20- Ta-ha";
$LANGUAGE[21] = "21- Al-Anbiyaa";
$LANGUAGE[22] = "22- Al-Hajj";
$LANGUAGE[23] = "23- Al-Muminun";
$LANGUAGE[24] = "24- An-Nur";
$LANGUAGE[25] = "25- Al-Furqan";
$LANGUAGE[26] = "26- Ash-Shu'araa";
$LANGUAGE[27] = "27- An-Naml";
$LANGUAGE[28] = "28- Al-Qasas";
$LANGUAGE[29] = "29- Al-Ankabut";
$LANGUAGE[30] = "30- Ar-Rum";
$LANGUAGE[31] = "31- Luqman";
$LANGUAGE[32] = "32- As-Sajda";
$LANGUAGE[33] = "33- Al-Ahzab";
$LANGUAGE[34] = "34- Saba";
$LANGUAGE[35] = "35- Fatir";
$LANGUAGE[36] = "36- Ya-Sin";
$LANGUAGE[37] = "37- As-Saffat";
$LANGUAGE[38] = "38- Sad";
$LANGUAGE[39] = "39- Az-Zumar";
$LANGUAGE[40] = "40- Ghafir";
$LANGUAGE[41] = "41- Fussilat";
$LANGUAGE[42] = "42- Ash-Shura";
$LANGUAGE[43] = "43- Az-Zukhruf";
$LANGUAGE[44] = "44- Ad-Dukhan";
$LANGUAGE[45] = "45- Al-Jathiya";
$LANGUAGE[46] = "46- Al-Ahqaf";
$LANGUAGE[47] = "47- Muhammad";
$LANGUAGE[48] = "48- Al-Fat-h";
$LANGUAGE[49] = "49- Al-Hujurat";
$LANGUAGE[50] = "50- Qaf";
$LANGUAGE[51] = "51- Az-Zariyat";
$LANGUAGE[52] = "52- At-Tur";
$LANGUAGE[53] = "53- An-Najm";
$LANGUAGE[54] = "54- Al-Qamar";
$LANGUAGE[55] = "55- Ar-Rahman";
$LANGUAGE[56] = "56- Al-Waqi'a";
$LANGUAGE[57] = "57- Al-Hadid";
$LANGUAGE[58] = "58- Al-Mujadila";
$LANGUAGE[59] = "59- Al-Hashr";
$LANGUAGE[60] = "60- Al-Mumtahana";
$LANGUAGE[61] = "61- As-Saff";
$LANGUAGE[62] = "62- Al-Jumu'a";
$LANGUAGE[63] = "63- Al-Munafiqun";
$LANGUAGE[64] = "64- At-Tagaboun";
$LANGUAGE[65] = "65- At-Talaq";
$LANGUAGE[66] = "66- At-Tahrim";
$LANGUAGE[67] = "67- Al-Mulk";
$LANGUAGE[68] = "68- Al-Qalam";
$LANGUAGE[69] = "69- Al-Haqqa";
$LANGUAGE[70] = "70- Al-Ma'arij";
$LANGUAGE[71] = "71- Nuh";
$LANGUAGE[72] = "72- Al-Jinn";
$LANGUAGE[73] = "73- Al-Muzzammil";
$LANGUAGE[74] = "74- Al-Muddathir";
$LANGUAGE[75] = "75- Al-Qiyamat";
$LANGUAGE[76] = "76- Al-Insan";
$LANGUAGE[77] = "77- Al-Mursalat";
$LANGUAGE[78] = "78- An-Nabaa";
$LANGUAGE[79] = "79- An-Nazi'at";
$LANGUAGE[80] = "80- Abasa";
$LANGUAGE[81] = "81- At-Takwir";
$LANGUAGE[82] = "82- Al-Infitar";
$LANGUAGE[83] = "83- Al-Mutaffifo";
$LANGUAGE[84] = "84- Al-Inshiqaq";
$LANGUAGE[85] = "85- Al-Buruj";
$LANGUAGE[86] = "86- At-Tariq";
$LANGUAGE[87] = "87- Al-A'la";
$LANGUAGE[88] = "88- Al-Gashiya";
$LANGUAGE[89] = "89- Al-Fajr";
$LANGUAGE[90] = "90- Al-Balad";
$LANGUAGE[91] = "91- Ash-Shams";
$LANGUAGE[92] = "92- Al-Lail";
$LANGUAGE[93] = "93- Adh-Dhuha";
$LANGUAGE[94] = "94- Al-Sharh";
$LANGUAGE[95] = "95- At-Tin";
$LANGUAGE[96] = "96- Al-Alaq";
$LANGUAGE[97] = "97- Al-Qadr";
$LANGUAGE[98] = "98- Al-Baiyina";
$LANGUAGE[99] = "99- Al-Zalzalah";
$LANGUAGE[100] = "100- Al-Adiyat";
$LANGUAGE[101] = "101- Al-Qari'a";
$LANGUAGE[102] = "102- At-Takathur";
$LANGUAGE[103] = "103- Al-Asr";
$LANGUAGE[104] = "104- Al-Humaza";
$LANGUAGE[105] = "105- Al-Fil";
$LANGUAGE[106] = "106- Quraish";
$LANGUAGE[107] = "107- Al-Ma'un";
$LANGUAGE[108] = "108- Al-Kauthar";
$LANGUAGE[109] = "109- Al-Kafirun";
$LANGUAGE[110] = "110- An-Nasr";
$LANGUAGE[111] = "111- Al-Masad";
$LANGUAGE[112] = "112- Al-Ikhlas";
$LANGUAGE[113] = "113- Al-Falaq";
$LANGUAGE[114] = " 114- Al-Nas";
$LANGUAGE[115] = "";
$LANGUAGE[116] = "";
$LANGUAGE[117] = "";
$LANGUAGE[118] = "";
$LANGUAGE[119] = "";
$LANGUAGE[120] = "";





$SEDANY[1] = "Right-click ---> Save Target As/Save Link As";
$SEDANY[2] = "اختر القارئ المفضل لك";
$SEDANY[3] = "للتحميل : ضع سهم الفأرة على السورة ثم اضغط بالزر الأيمن للفأرة واضغط حفظ باسم ";
$SEDANY[4] = "  Copy the code to add this Recitation to your site: ";
$SEDANY[5] = "Click here to download Full Quran";
$SEDANY[6] = "اسم القارئ";
$SEDANY[7] = "نوع القراءة";
$SEDANY[8] = "المصحف مرتل";
$SEDANY[9] = " أن رسول الله قال : ( من قرأ القرآن وعمل بما فيه ألبس الله والديه تاجا يوم القيامة ضوؤه أحسن من ضوء الشمس في بيوت الدنيا فما ظنكم بالذي عمل بهذا ) رواه أبو داود";
$SEDANY[10] = "::: القرآن الكريم :::";
$SEDANY[11] = "ساهم معنا";

$soot[1] = "Abdelbasset Abdessamad";
$soot[2] = " Ahmad ben 'Ali Al-Ajmi";
$soot[3] = "Abdelbasset Abdessamad";
$soot[4] = "Mohamed Seddik El Manchaoui";
$soot[5] = "Mohamed Seddik El Manchaoui";
$soot[6] = "Abderrahman Soudais";
$soot[7] = "Abdullah Awad Al Juhani";
$soot[8] = "Maher Al Mueaqly";
$soot[9] = "Saoud Shuraim";
$soot[10] = "Saad El Ghamidi";
$soot[11] = "Fares Abbad";
$soot[12] = "Machari Rashed Al Afassi";
$soot[13] = "Adel Rayane";
$soot[14] = "Hani Ar Rifai";
$soot[15] = "Alzain Mohamed Ahmed";
$soot[16] = "Zaki Daghistani";
$soot[17] = "Ibrahim Al Akhdar";
$soot[18] = "Hatem Fareed Alwaer";
$soot[19] = "Ali Jaber";
$soot[20] = "Jamal Shaker Abdullah";
$soot[21] = "Nabil Ar Rifai";
$soot[22] = "Abdul Rashid Ali Sufi";
$soot[23] = "Yasser Al Dossari";
$soot[24] = "Abdullah Ibn Ali Basfar";
$soot[25] = "Muhammad Jebril";
$soot[26] = "Abdullah Al Khayat ";
$soot[27] = "Adil Muslim";
$soot[28] = " Abou Bakr Ach Chatiri";
$soot[29] = " Yaseen ";
$soot[30] = "Abdulmohsen Al Qasim";
$soot[31] = "Tawfik As Sayegh";
$soot[32] = "Yousouf Al Chaw'i";
$soot[33] = "Abdel Aziz Al Ahmed";
$soot[34] = "Salah Bukhatir";
$soot[35] = " Al Doukkali Mohammed Al Alem";
$soot[36] = "Abdulhadi Kanakeri";
$soot[37] = "Khalifa Al Tunaiji";
$soot[38] = "Salah Al Budair";
$soot[39] = "Shirazad Taher";
$soot[40] = "Khaled Abdelkafi";
$soot[41] = "Adel Al Kalbani";
$soot[42] = "Abdelbari al tabiti";
$soot[43] = "Salah al-Najjar";
$soot[44] = "Mohamed Abdelkarim";
$soot[45] = "Mahmoud Khalil Al Hussary";
$soot[46] = "Abdallah Matroud";
$soot[47] = "Khaled Al Qahtani";
$soot[48] = "Omar Al Qazabri";
$soot[49] = "Sahl Yassin";
$soot[50] = "Ali al-houdaifi";


$addthis = "
<!-- AddThis Button BEGIN -->
<div class='addthis_toolbox addthis_default_style '>
<a class='addthis_button_preferred_1'></a>
<a class='addthis_button_preferred_2'></a>
<a class='addthis_button_preferred_3'></a>
<a class='addthis_button_preferred_4'></a>
<a class='addthis_button_compact'></a>
<a class='addthis_counter addthis_bubble_style'></a>
</div>
<script type='text/javascript' src='http://s7.addthis.com/js/250/addthis_widget.js#pubid=xa-4e0bb9cb57f3dc95'></script>
<!-- AddThis Button END -->

";





////////////////لا تقم بتعديل شيئ بالاسفل //////////////////////
//------------------link Abdulbasit-------------------------///
$linkAbdulbasit = "http://ia600205.us.archive.org/19/items/TvQuran.com__basit/";
//------------------link AlAjmy-------------------------///
$linkAlAjmy = "http://ia600205.us.archive.org/1/items/TvQuran.com__Al-Ajmy/";
//------------------link Abdulbasit_Mojawwad-------------------------///
$linkAbdulbasit_Mojawwad = "http://ia600205.us.archive.org/8/items/TvQuran.com__basit_mjwd/";
//------------------link AlMinshawi-------------------------///
$linkAlMinshawi = "http://ia600200.us.archive.org/3/items/TvQuran.com__Al-Minshawi/";
//------------------link AlMinshawi_Mojawwad-------------------------///
$linkAlMinshawi_Mojawwad = "http://ia600205.us.archive.org/19/items/TvQuran.com__Al-Minshawi-Mojawad/";
//------------------link Alsudaes-------------------------///
$linkAlsudaes = "http://ia600205.us.archive.org/23/items/TvQuran.com__Alsdes/";
//------------------link AlJohany-------------------------///
$linkAlJohany = "http://ia600308.us.archive.org/15/items/TvQuran.com__Al-Johany/";
//------------------link maher-------------------------///
$linkmaher = "http://ia600205.us.archive.org/15/items/TvQuran.com__Maher/";
//------------------link AlShuraim-------------------------///
$linkAlShuraim = "http://ia600205.us.archive.org/13/items/TvQuran.com__Al-Shuraim/";
//------------------link AlGhamdi-------------------------///
$linkAlGhamdi = "http://ia600205.us.archive.org/23/items/TvQuran.com__Al-Ghamdi/";
//------------------link Fares-------------------------///
$linkFares = "http://ia600209.us.archive.org/6/items/TvQuran.com__Fares.Abbad/";
//------------------link Alafasi-------------------------///
$linkAlafasi ="http://ia600504.us.archive.org/21/items/TvQuran.com__Alafasi/";







//------------------link -------------------------///
$linkadelrayan = "http://ia600400.us.archive.org/5/items/TvQuran.com__Ryan/";
$linkHani = "http://ia600205.us.archive.org/13/items/TvQuran.com__Hani/"; 
$linkzain = "http://ia600309.us.archive.org/26/items/TvQuran.com__Zain/"; 
$linkzaki = "http://ia600305.us.archive.org/11/items/TvQuran.com__Zaki/"; 
$linkalakhdar = "http://ia600505.us.archive.org/12/items/tvQuran.com__Alakhdar/";
$linkhatem = "http://ia700506.us.archive.org/1/items/TvQuran.com__Hatem/"; 
$linkJaber = "http://ia700202.us.archive.org/8/items/TvQuran.com__Jaber/";
$linkjamal = "http://ia600205.us.archive.org/17/items/TvQuran.com__Jamal/";
$linknabil = "http://ia600209.us.archive.org/11/items/TvQuran.com__Nabil/"; 
$linksoufi = "http://ia600402.us.archive.org/6/items/TvQuran.com__soufi/";
$linkAlDosari = "http://ia600205.us.archive.org/23/items/TvQuran.com__Yasser/";
$linkbasfar = "http://ia600209.us.archive.org/1/items/TvQuran.com__Basfar/"; 
$linkJibrel = "http://ia600402.us.archive.org/34/items/TvQuran.com__Jibrel/"; 
$linkkhayat = "http://ia600302.us.archive.org/11/items/TvQuran.com__Khayat/"; 
$linkmuslim = "http://ia600305.us.archive.org/23/items/TvQuran.com__Muslim/"; 
$linkShatri = "http://ia600205.us.archive.org/8/items/TvQuran.com__Shatri/"; 
$linkyaseen = "http://ia600205.us.archive.org/3/items/TvQuran.com__Yaseen/";
$linkalqasim = "http://ia600400.us.archive.org/5/items/TvQuran.com__Alqasim/";
$linkTawfeeqAsSayegh = "http://ia600205.us.archive.org/14/items/TvQuran.com__Tawfeeq/";
$linkyoussef = "http://ia600502.us.archive.org/7/items/TvQuran.com__Youssef/"; 
$linkAlAhmad = "http://ia600508.us.archive.org/7/items/TvQuran.com__Al-Ahmad/"; 
$linkBukhatir = "http://ia600400.us.archive.org/2/items/TvQuran.com__Bukhatir/";
$linkdoukkali = "http://ia700300.us.archive.org/30/items/TvQuran.com__doukkali/";
$linkKanakeri = "http://ia600403.us.archive.org/0/items/TvQuran.com__Kanakeri/";
$linkkhalifa = "http://ia600505.us.archive.org/23/items/TvQuran.com__Khalifah/"; 
$linkSalahAlbudair = "http://ia600404.us.archive.org/21/items/TvQuran.com__Albudair/"; 
$linkShirazadTaher = "http://ia600408.us.archive.org/30/items/TvQuran.com__Shirazad/"; 
$linkabdulkafi = "http://ia700305.us.archive.org/19/items/TvQuran.com__Abdulkafi/"; 
$linkalkalbany = "http://ia600504.us.archive.org/9/items/TvQuran.com__alkalbany/"; 
$linkathobaity = "http://ia600305.us.archive.org/4/items/TvQuran.com__Athobaity/";
$linkelnajjar = "http://ia600309.us.archive.org/12/items/TvQuran.com__El-Najjar/"; 
$linkMohamadAbdullkarem = "http://ia600402.us.archive.org/9/items/TvQuran.com__Abdlkarem/";
$linkAlHussary = "http://ia700205.us.archive.org/19/items/TvQuran.com__Al-Hussary/";
$linkAlMattrod = "http://ia600405.us.archive.org/2/items/TvQuran.com__Al-Mattrod/"; 
$linkAlQahtani = "http://ia600205.us.archive.org/10/items/TvQuran.com__Al-Qahtani/";
$linkAlQazabri = "http://ia700405.us.archive.org/21/items/TvQuran.com__Al-Qazabri/"; 
$linkSahlYassin = "http://ia600401.us.archive.org/2/items/TvQuran.com__Sahl-Yassin/"; 
$linkAliAlhuthaifi = "http://ia700502.us.archive.org/23/items/TvQuran.com__Ali-Alhuthaifi/"; 




//////////////// لتحميل المصحف الكامل برابط واحد  //////////////////////

$itemsAlafasi = "http://ia700400.us.archive.org/32/items/TvQuran.com__AlafasiZip/TvQuran.com__Alafasi.zip";
$itemsAbdulbasitMojawwad = "http://ia600400.us.archive.org/14/items/TvQuran.com__basit_mjwdZip/TvQuran.com__Abdulbasit_Mjwd.zip";
$itemsAlAjmy = "http://ia600205.us.archive.org/13/items/TvQuran.com__Al-AjmyZip/TvQuran.com__Al-Ajmy.zip";
$itemsAbdulbasit = "http://ia600403.us.archive.org/11/items/TvQuran.com__abdulbasitZip/TvQuran.com__abdulbasit.zip";
$itemsAlMinshawi = "http://ia600405.us.archive.org/17/items/TvQuran.com__Al-MinshawiZip/TvQuran.com__Al-Minshawi.zip";
$itemsAlMinshawiMojawwad = "http://ia600408.us.archive.org/29/items/TvQuran.com__Al-Minshawi-MojawwadZip/TvQuran.com__Al-Minshawi-Mojawwad.zip";
$itemsAlsudaes = "http://ia700401.us.archive.org/4/items/TvQuran.com__AlsdesZip/TvQuran.com__Alsdes.zip";
$itemsAlJohany = "http://ia600405.us.archive.org/21/items/TvQuran.com__Al-JohanyZip/TvQuran.com__Al-Johany.zip";
$itemsmaher = "http://ia600205.us.archive.org/4/items/TvQuran.com__MaherZip/TvQuran.com__Maher.zip";
$itemsAlShuraim = "http://ia600403.us.archive.org/13/items/TvQuran.com__Al-ShuraimZip/TvQuran.com__Al-Shuraim.zip";
$itemsAlGhamdi = "http://ia600402.us.archive.org/0/items/TvQuran.com__Al-GhamdiZip/TvQuran.com__Al-Ghamdi.zip";
$itemsFares = "http://ia700409.us.archive.org/5/items/TvQuran.com__Fares.AbbadZip/TvQuran.com__Fares.Abbad.zip";



//////////////// لتحميل المصحف الكامل برابط واحد  //////////////////////

$itemsabdulkafi = "http://ia600400.us.archive.org/32/items/TvQuran.com__AbdulkafiZip/TvQuran.com__Abdulkafi.zip";
$itemsadelrayan = "http://ia600403.us.archive.org/34/items/TvQuran.com__RayanZip/TvQuran.com__Rayan.zip";
$itemsAlAhmad = "http://ia600403.us.archive.org/12/items/TvQuran.com__Al-AhmadZip/TvQuran.com__Al-Ahmad.zip";
$itemsalakhdar = "http://ia700405.us.archive.org/28/items/TvQuran.com__AlakhdarZip/TvQuran.com__Alakhdar.zip";
$itemsAlDosari = "#";
$itemsAlHussary = "http://ia600405.us.archive.org/16/items/TvQuran.com__Al-HussaryZip/TvQuran.com__Al-Hussary.zip";
$itemsAliAlhuthaifi = "http://ia600403.us.archive.org/21/items/TvQuran.com__Ali-AlhuthaifiZip/TvQuran.com__Ali-Alhuthaifi.zip";
$itemsalkalbany = "http://ia600403.us.archive.org/25/items/TvQuran.com__AlkalbanyZip/TvQuran.com__Alkalbany.zip";
$itemsAlMattrod = "http://ia600405.us.archive.org/3/items/TvQuran.com__Al-MattrodZip/TvQuran.com__Al-Mattrod.zip";
$itemsAlQahtani = "http://ia600205.us.archive.org/20/items/TvQuran.com__Al-QahtaniZip/TvQuran.com__Al-Qahtani.zip";
$itemsalqasim = "http://ia600403.us.archive.org/35/items/TvQuran.com__AlqasimZip/TvQuran.com__Alqasim.zip";
$itemsAlQazabri = "http://ia600403.us.archive.org/3/items/TvQuran.com__Al-QazabriZip/TvQuran.com__Al-Qazabri.zip";
$itemsathobaity = "http://ia600405.us.archive.org/12/items/TvQuran.com__AthobaityZip/TvQuran.com__Athobaity.zip";
$itemsbasfar = "http://ia600403.us.archive.org/9/items/TvQuran.com__BasfarZip/TvQuran.com__Basfar.zip";
$itemsBukhatir = "http://ia600403.us.archive.org/6/items/TvQuran.com__BukhatirZip/TvQuran.com__Bukhatir.zip";
$itemsdoukkali = "http://ia600400.us.archive.org/8/items/TvQuran.com__DoukkaliZip/TvQuran.com__Doukkali.zip";
$itemsdoukkali = "http://ia600400.us.archive.org/8/items/TvQuran.com__DoukkaliZip/TvQuran.com__Doukkali.zip";
$itemselnajjar = "http://ia600405.us.archive.org/32/items/TvQuran.com__El-NajjarZip/TvQuran.com__El-Najjar.zip";
$itemsHani = "http://ia700403.us.archive.org/12/items/TvQuran.com__HaniZip/TvQuran.com__Hani.zip";
$itemshatem = "http://ia600401.us.archive.org/13/items/TvQuran.com__HatemZip/TvQuran.com__Hatem.zip";
$itemsJaber = "http://ia600405.us.archive.org/6/items/TvQuran.com__JaberZip/TvQuran.com__Jaber.zip";
$itemsjamal = "http://ia700400.us.archive.org/30/items/TvQuran.com__JamalZip/TvQuran.com__Jamal.zip";
$itemsJibrel = "http://ia600405.us.archive.org/28/items/TvQuran.com__JibrelZip/TvQuran.com__Jibrel.zip";
$itemsKanakeri = "http://ia600405.us.archive.org/28/items/TvQuran.com__KanakeriZip/TvQuran.com__Kanakeri.zip";
$itemskhalifa = "http://ia600405.us.archive.org/1/items/TvQuran.com__KhalifahZip/TvQuran.com__Khalifah.zip";
$itemskhayat = "http://ia600405.us.archive.org/18/items/TvQuran.com__KhayatZip/TvQuran.com__Khayat.zip";
$itemsMohamadAbdullkarem = "http://ia700405.us.archive.org/8/items/TvQuran.com__AbdlkaremZip/TvQuran.com__Abdlkarem.zip";
$itemsmuslim = "http://ia600402.us.archive.org/35/items/TvQuran.com__MuslimZip/TvQuran.com__Muslim.zip";
$itemsnabil = "http://ia700403.us.archive.org/27/items/TvQuran.com__NabilZip/TvQuran.com__Nabil.zip";
$itemsSahlYassin = "http://ia600403.us.archive.org/32/items/TvQuran.com__Sahl-YassinZip/TvQuran.com__Sahl-Yassin.zip";
$itemsSalahAlbudair = "http://ia600405.us.archive.org/21/items/TvQuran.com__AlbudairZip/TvQuran.com__Albudair.zip";
$itemsShatri = "http://ia600405.us.archive.org/3/items/TvQuran.com__ShatriZip/TvQuran.com__Shatri.zip";
$itemsShirazadTaher = "http://ia700403.us.archive.org/1/items/TvQuran.com__ShirazadZip/TvQuran.com__Shirazad.zip";
$itemssoufi = "http://ia700403.us.archive.org/14/items/TvQuran.com__soufiZip/TvQuran.com__soufi.zip";
$itemsTawfeeqAsSayegh = "http://ia700403.us.archive.org/6/items/TvQuran.com__TawfeeqZip/TvQuran.com__Tawfeeq.zip";
$itemsyaseen = "http://ia600405.us.archive.org/16/items/TvQuran.com__YaseenZip/TvQuran.com__Yaseen.zip";
$itemsyoussef = "http://ia600409.us.archive.org/10/items/TvQuran.com__YoussefZip/TvQuran.com__Youssef.zip";
$itemszain = "http://ia600403.us.archive.org/34/items/TvQuran.com__ZainZip/TvQuran.com__Zain.zip";
$itemszaki = "http://ia600405.us.archive.org/23/items/TvQuran.com__ZakiZip/TvQuran.com__Zaki.zip";
$linkhd ="
<div class='crt2'>
<div class='crt-r'> <h3> اذكار الصباح والمساء </h3> </div>
<div class='crt'>
<marquee direction='right' > لا الـه الا الله وحده لا شريك له، له الملك ، وله الحمد ، وهو على كل شيء قدير,اللهم إني اعوذ بك ان اشرك بك وانا اعلم، واستغفرك لما لا اعلم,(( اللهم لك صمت وعلى رزقك افطرت فتقبل منا انك أنت السميع العليم,اللهم إني اسألك برحمتك التي وسعت كل شيء أن تغفر لي,ذهب الظماء وابتلت العروق وثبت الاجر ان شاء الله)),سبحانك اللهم وبحمدك أشهد أن لا ألـه إلا أنت، استغفرك وأتوب اليك, اللهم اغفر لي ، وارحمني ، واهدني، وعافين و ارزقني , لا الـه الا الله وحده لا شريك له، له الملك ، وله الحمد ، وهو على كل شيء قدير</marquee>
</div>
</div>
";


?>
<?php

$LANGUAGE=array("sedany.com",
"1- الفاتحة ",
"2- البقرة ",
"3- آل عمران ",
"4- النساء ",
"5- المائدة ",
"6- الأنعام ",
"7- الأعراف ",
"8- الأنفال ",
"9- التوبة ",
"10- يونس ",
"11- هود ",
"12- يوسف ",
"13- الرعد ",
"14- إبراهيم ",
"15- الحجر ",
"16- النحل ",
"17- الإسراء ",
"18- الكهف ",
"19- مريم ",
"20- طه ",
"21- الأنبياء ",
"22- الحج ",
"23- المؤمنون ",
"24- النّور ",
"25- الفرقان ",
"26- الشعراء ",
"27- النّمل ",
"28- القصص ",
"29- العنكبوت ",
"30- الرّوم ",
"31- لقمان ",
"32- السجدة ",
"33- الأحزاب ",
"34- سبأ",
"35- فاطر",
"36- يس",
"37- الصافات ",
"38- ص",
"39- الزمر",
"40- غافر",
"41- فصّلت",
"42- الشورى",
"43- الزخرف",
"44- الدّخان",
"45- الجاثية",
"46- الأحقاف",
"47- محمد",
"48- الفتح",
"49- الحجرات",
"50- ق",
"51- الذاريات",
"52- الطور",
"53- النجم",
"54- القمر",
"55- الرحمن",
"56- الواقعة",
"57- الحديد",
"58- المجادلة",
"59- الحشر",
"60- الممتحنة",
"61- الصف",
"62- الجمعة",
"63- المنافقون",
"64- التغابن",
"65- الطلاق",
"66- التحريم",
"67- الملك",
"68- القلم",
"69- الحاقة",
"70- المعارج",
"71- نوح",
"72- الجن",
"73- المزّمّل",
"74- المدّثر",
"75- القيامة",
"76- الإنسان",
"77- المرسلات",
"78- النبأ",
"79- النازعات",
"80- عبس",
"81- التكوير",
"82- الإنفطار",
"83- المطفّفين",
"84- الإنشقاق",
"85- البروج",
"86- الطارق",
"87- الأعلى",
"88- الغاشية",
"89- الفجر",
"90- البلد",
"91- الشمس",
"92- الليل",
"93- الضحى",
"94- الشرح",
"95- التين",
"96- العلق",
"97- القدر",
"98- البينة",
"99- الزلزلة",
"100- العاديات",
"101- القارعة",
"102- التكاثر",
"103- العصر",
"104- الهمزة",
"105- الفيل",
"106- قريش",
"107- الماعون",
"108- الكوثر",
"109- الكافرون",
"110- النصر",
"111- المسد",
"112- الإخلاص",
"113- الفلق",
" 114- النّاس",
"Toyota"
);


$soot= array(
"  اختر القارئ المفضل لك ",
"عبدالباسط عبدالصمد",
"أحمد بن علي العجمي",
"عبد الباسط عبد الصمد",
"محمد صديق المنشاوي",
"محمد صديق المنشاوي",
"عبدالرحمن السديس",
"عبدالله عواد الجهني",
"ماهر المعيقلي",
"سعود الشريم",
"سعد الغامدي",
"فارس عباد",
"مشاري العفاسي",
"عادل ريان",
"هاني الرفاعي",
"الزين محمد أحمد",
"زكي داغستاني",
"إبراهيم الأخضر",
"حاتم فريد الواعر",
"علي جابر",
"جمال شاكر عبد الله",
"نبيل الرفاعي",
"عبدالرشيد بن علي صوفي",
"ياسر الدوسري",
"عبدالله بصفر",
"محمد جبريل",
"عبدالله خياط",
"عادل مسلم",
"شيخ أبو بكر الشاطري",
"ياسين ",
"عبدالمحسن القاسم",
"توفيق الصايغ",
"يوسف الشويعي",
"عبدالعزيز الأحمد",
"صلاح بو خاطر",
"الدوكالي محمد العالم",
"عبدالهادي كناكري",
"خليفة الطنيجي",
"صلاح البدير",
"شيرزاد طاهر",
"خالد عبدالكافي",
"عادل الكلباني",
"عبدالبارئ الثبيتي",
"صلاح النجار",
"محمد عبدالكريم",
"محمود خليل الحصري",
"عبد الله المطرود",
"خالد القحطاني",
"عمر القزابري",
"سهل ياسين",
"علي الحذيفي",
"عبدالمجيب بنكيران",
"عبد الكبير الحديدي",
"عبدالباسط عبدالصمد",
"عبدالمحسن الحارثي",
"عبد القوي عبد المجيد",
"عبدالرحمن الجريذي",
"إدريس أبكر",
"أحمد خضر الطرابلسي",
"أحمد نعينع",
"عبدالولي الأركاني",
" إبراهيم العسيري",
"محمود علي البنا",
"محمود علي البنا - المصحف المجود",
"محمد البراك",
"صلاح الهاشم",
"000000",
"فهد الكندري",
"محمد اللحيدان",
"محمد صديق المنشاوي - المصحف المجود",
"لافي العوني",
"ناصر القطامي",
"أيمن أحمد الديب",
"محمد أيوب",
"مصطفى بن رعد العزاوي",
"ممحمد الكنتاوي - رواية ورش عن نافع",
"فؤاد الخامري",
"حافظ إسحاق دانيش",
"عبدالودود مقبول حنيف",
"حسن محمد صالح (برواية ورش عن نافع)",
"أحمد الحواشي",
"جزاع بن فليح الصويلح",
"ابراهيم الجبرين",
"خالد الجليل",
"العيون الكوشي (رواية ورش عن نافع)",
"مصطفى اللاهوني",
"محمود الرفاعي",
"منصور الزهراني",
"محمد المحيسني",
"محمد عبدالحكيم سعيد العبدالله - الدوري عن الكسائي",
"محمد الحضيري - رواية قالون عن نافع",
"محمد حسان",
"مصطفى إسماعيل",
"ياسر سلامة - مصحف الحدر",
"سامي الحسن",
"ماهر شخاشيرو",
"سلطان الروكان",
"محمد محمود الطبلاوي",
"وليد الدليمي",
"يحيى حوا",
"يوسف أبكر",
"يوسف نوح أحمد",
"ماجد الزامل");


$SEDANY[1] = "اضغط بالزر الأيمن للفأرة واضغط حفظ باسم";
$SEDANY[2] = "اختر القارئ المفضل لك";
$SEDANY[3] = "للتحميل : ضع سهم الفأرة على السورة ثم اضغط بالزر الأيمن للفأرة واضغط حفظ باسم ";
$SEDANY[4] = "هل لديك موقع أو مدونة؟ يمكنك اضافة   القرأن الكريم  الى موقعك الان! انسخ الكود التالي و ضعه في موقعك!";
$SEDANY[5] = "لتحميل المصحف الكامل برابط واحد اضغط هنا";
$SEDANY[6] = "اسم القارئ";
$SEDANY[7] = "نوع القراءة";
$SEDANY[8] = "المصحف مرتل";
$SEDANY[9] = " أن رسول الله قال : ( من قرأ القرآن وعمل بما فيه ألبس الله والديه تاجا يوم القيامة ضوؤه أحسن من ضوء الشمس في بيوت الدنيا فما ظنكم بالذي عمل بهذا ) رواه أبو داود";
$SEDANY[10] = "::: القرآن الكريم :::";
$SEDANY[11] = "ساهم معنا";
$SEDANY[12] = "المصحف المجود";
$SEDANY[13] = "مصحف الحدر";
$SEDANY[14] = "رواية ورش عن نافع";
$SEDANY[15] = "الدوري عن الكسائي";
$SEDANY[16] = "رواية قالون عن نافع";




$addthis = "
<!-- AddThis Button BEGIN -->
<div class='addthis_toolbox addthis_default_style '>
<a class='addthis_button_preferred_1'></a>
<a class='addthis_button_preferred_2'></a>
<a class='addthis_button_preferred_3'></a>
<a class='addthis_button_preferred_4'></a>
<a class='addthis_button_compact'></a>
<a class='addthis_counter addthis_bubble_style'></a>
</div>
<script type='text/javascript' src='http://s7.addthis.com/js/250/addthis_widget.js#pubid=xa-4e0bb9cb57f3dc95'></script>
<!-- AddThis Button END -->
";


$itemsabdelmoujibbenkirane = "http://ia801608.us.archive.org/21/items/tvQuran.com__Benkirane/tvQuran.com__Abdelmoujib-Benkirane.zip";
$itemsabdlkaber = "http://ia600603.us.archive.org/30/items/TvQuran.com__AbdlkaberZip/TvQuran.com__abdelkaber.zip";
$itemsAbdulbasit_Mojawwad = "http://ia600400.us.archive.org/14/items/TvQuran.com__basit_mjwdZip/TvQuran.com__Abdulbasit_Mjwd.zip";
$itemsAbdulmuhsin_Al_Harthy = "";
$itemsabdulqawi_abdulmajid = "";
$itemsabdulrhman_aljuraidy = "http://ia601603.us.archive.org/34/items/tvQuran.com_Abderrahman-aljouraidy/tvQuran.com__Abdulrhman-Aljuraidy.zip";
$itemsabkar = "";
$itemsahmed_attarabolsi = "http://ia600807.us.archive.org/17/items/tvQuran.com__AttarabolsiZip/tvQuran.com__Attarabolsi.zip";
$itemsahmed_neana = "http://ia601503.us.archive.org/27/items/tvQuran.com__Ahmed-NeanaZip/tvQuran.com__Ahmed-Neana.zip";
$itemsAl_Arkani = "";
$itemsAl_Asiri = "";
$itemsalbana = "http://ia700405.us.archive.org/29/items/TvQuran.com__AlbanaZip/TvQuran.com__Albana.zip";
$itemsalbana_mjwd = "http://tvquranserver.com/download/TvQuran.com__Albana-MjwdZip/TvQuran.com__Albana-Mjwd.zip";
$itemsAl_Barrak = "";
$itemsalhashim = "http://ia600405.us.archive.org/13/items/TvQuran.com__AlhashimZip/TvQuran.com__Alhashim.zip";
$itemsAl_Kandari = "";
$itemsAl_Lohaidan = "http://ia600407.us.archive.org/31/items/TvQuran.com__Al-LohaidanZip/TvQuran.com__Al-Lohaidan.zip";



$itemsAl_Minshawi_Mojawwad = "http://ia600408.us.archive.org/29/items/TvQuran.com__Al-Minshawi-MojawwadZip/TvQuran.com__Al-Minshawi-Mojawwad.zip";
$itemsAl_Oni = "";
$itemsAlqatami = "";
$itemsayman_aldeeb = "http://ia700801.us.archive.org/29/items/tvQuran.com_Ayman-AldeebZip/tvQuran.com_Ayman-Aldeeb.zip";
$itemsAyyub = "http://ia600405.us.archive.org/20/items/TvQuran.com__AyyubZip/tvQuran.com__Ayyub.zip";
$itemsazzawi = "http://ia700404.us.archive.org/26/items/TvQuran.com__AzzawiZip/TvQuran.com__Azzawi.zip";
$itemselkantaoui = "http://ia700405.us.archive.org/24/items/TvQuran.com__ElkantaouiZip/TvQuran.com__Elkantaoui.zip";
$itemsfouad_alkhamri = "";
$itemshafez_ishak_danish = "http://ia700800.us.archive.org/34/items/tvQuran.com__Ishak-DanishZip/tvQuran.com__Ishak-Danish.zip";
$itemshaneef = "http://ia600405.us.archive.org/18/items/TvQuran.com__HaneefZip/TvQuran.com__Haneef.zip";
$itemshasan_mohamed_saleh_warsh = "http://ia700806.us.archive.org/34/items/tvQuran.com__Hasan-Mohamed-Saleh-WarshZip/tvQuran.com__Hasan-Mohamed-Saleh-Warsh.zip";
$itemshawashy = "http://ia600706.us.archive.org/13/items/tvQuran.com__HawashyZip/tvQuran.com__Hawashy.zip";
$itemsjazza_alsuwaileh = "http://ia600806.us.archive.org/28/items/tvQuran.com__Jazza-AlsuwailehZip/tvQuran.com__Jazza-Alsuwaileh.zip";
$itemsjbreen = "";
$itemsjleel = "";
$itemskoshi = "http://ia700205.us.archive.org/16/items/TvQuran.com__koshiZip/tvQuran.com__koshi.zip";
$itemslahoni = "http://ia700502.us.archive.org/32/items/TvQuran.com__Al-LahoniZip/TvQuran.com__Al-Lahoni.zip";
$itemsmahmoud_rifai = "";
$itemsMansoor = "";
$itemsmhsny = "http://ia700407.us.archive.org/11/items/TvQuran.com__MhsnyZip/TvQuran.com__Mhsny.zip";
$itemsmohamed_alabdulah = "";
$itemsmohamed_elhodairi = "http://ia600807.us.archive.org/8/items/tvQuran.com__ElhodairiZip/tvQuran.com__Elhodairi.zip";
$itemsmohamed_hassan = "http://ia600803.us.archive.org/11/items/tvQuran.com__Mohamed-HassanZip/tvQuran.com__Mohamed-Hassan.zip";
$itemsmustafaismail = "http://ia600705.us.archive.org/31/items/TvQuran.com__MustafaIsmailZip/TvQuran.com__MustafaIsmail.zip";
$itemssalama_hdr = "http://ia600409.us.archive.org/30/items/TvQuran.com__Salama-hdrZip/TvQuran.com__Salama-hdr.zip";
$itemsSami_Al_Hasn = "";
$itemsshakhashero = "http://ia700403.us.archive.org/17/items/TvQuran.com__ShakhasheroZip/TvQuran.com__Shakhashero.zip";
$itemssultan_alrukan = "";
$itemstablawi = "http://ia700403.us.archive.org/0/items/TvQuran.com__TablawiZip/TvQuran.com__Tablawi.zip";
$itemsWalid_Al_Dulaimi = "";
$itemsyahya = "http://ia600403.us.archive.org/7/items/TvQuran.com__YahyaZip/TvQuran.com__Yahya.zip";
$itemsyoussef_abkar = "";
$itemsyoussef_nouh = "http://ia700802.us.archive.org/8/items/tvQuran.com__Youssef-Nouh-AhmedZip/tvQuran.com__Youssef-Nouh-Ahmed.zip";
$itemszamil = "";


////////////////لا تقم بتعديل شيئ بالاسفل //////////////////////
//------------------link Abdulbasit-------------------------///
$linkAbdulbasit = "http://ia701509.us.archive.org/15/items/TvQuran.com__basit/";
//------------------link AlAjmy-------------------------///
$linkAlAjmy = "http://ia701509.us.archive.org/21/items/TvQuran.com__Al-Ajmy/";
//------------------link AlMinshawi-------------------------///
$linkAlMinshawi = "http://ia600200.us.archive.org/3/items/TvQuran.com__Al-Minshawi/";
//------------------link AlMinshawi_Mojawwad-------------------------///
$linkAlMinshawi_Mojawwad = "http://ia601509.us.archive.org/30/items/TvQuran.com__Al-Minshawi-Mojawad/";
//------------------link Alsudaes-------------------------///
$linkAlsudaes = "http://ia601509.us.archive.org/28/items/TvQuran.com__Alsdes/";
//------------------link AlJohany-------------------------///
$linkAlJohany = "http://ia600308.us.archive.org/15/items/TvQuran.com__Al-Johany/";
//------------------link maher-------------------------///
$linkmaher = "http://ia701509.us.archive.org/25/items/TvQuran.com__Maher/";
//------------------link AlShuraim-------------------------///
$linkAlShuraim = "http://ia601702.us.archive.org/28/items/shraim/";
//------------------link AlGhamdi-------------------------///
$linkAlGhamdi = "http://ia601509.us.archive.org/15/items/TvQuran.com__Al-Ghamdi/";
//------------------link Fares-------------------------///
$linkFares = "http://ia601509.us.archive.org/25/items/TvQuran.com__Fares.Abbad/";
//------------------link Alafasi-------------------------///
$linkAlafasi ="http://ia601509.us.archive.org/12/items/TvQuran.com__Alafasi/";
//------------------link -------------------------///
$linkadelrayan = "http://ia600400.us.archive.org/5/items/TvQuran.com__Ryan/";
$linkHani = "http://ia600205.us.archive.org/13/items/TvQuran.com__Hani/"; 
$linkzain = "http://ia600309.us.archive.org/26/items/TvQuran.com__Zain/"; 
$linkzaki = "http://ia600305.us.archive.org/11/items/TvQuran.com__Zaki/"; 
$linkalakhdar = "http://ia600505.us.archive.org/12/items/tvQuran.com__Alakhdar/";
$linkhatem = "http://ia700506.us.archive.org/1/items/TvQuran.com__Hatem/"; 
$linkJaber = "http://ia700202.us.archive.org/8/items/TvQuran.com__Jaber/";
$linkjamal = "http://ia600205.us.archive.org/17/items/TvQuran.com__Jamal/";
$linknabil = "http://ia600209.us.archive.org/11/items/TvQuran.com__Nabil/"; 
$linksoufi = "http://ia600402.us.archive.org/6/items/TvQuran.com__soufi/";
$linkAlDosari = "http://ia701509.us.archive.org/12/items/TvQuran.com__Yasser/";
$linkbasfar = "http://ia600209.us.archive.org/1/items/TvQuran.com__Basfar/"; 
$linkJibrel = "http://ia600402.us.archive.org/34/items/TvQuran.com__Jibrel/"; 
$linkkhayat = "http://ia600302.us.archive.org/11/items/TvQuran.com__Khayat/"; 
$linkmuslim = "http://ia600305.us.archive.org/23/items/TvQuran.com__Muslim/"; 
$linkShatri = "http://tvquranserver.com/download/TvQuran.com__Shatri/"; 
$linkyaseen = "http://ia600205.us.archive.org/3/items/TvQuran.com__Yaseen/";
$linkalqasim = "http://ia600400.us.archive.org/5/items/TvQuran.com__Alqasim/";
$linkTawfeeqAsSayegh = "http://ia600205.us.archive.org/14/items/TvQuran.com__Tawfeeq/";
$linkyoussef = "http://ia600502.us.archive.org/7/items/TvQuran.com__Youssef/"; 
$linkAlAhmad = "http://ia600508.us.archive.org/7/items/TvQuran.com__Al-Ahmad/"; 
$linkBukhatir = "http://ia600400.us.archive.org/2/items/TvQuran.com__Bukhatir/";
$linkdoukkali = "http://ia700300.us.archive.org/30/items/TvQuran.com__doukkali/";
$linkKanakeri = "http://ia600403.us.archive.org/0/items/TvQuran.com__Kanakeri/";
$linkkhalifa = "http://ia700307.us.archive.org/29/items/TvQuran.com__Khalifah/"; 
$linkSalahAlbudair = "http://ia600404.us.archive.org/21/items/TvQuran.com__Albudair/"; 
$linkShirazadTaher = "http://ia600408.us.archive.org/30/items/TvQuran.com__Shirazad/"; 
$linkabdulkafi = "http://ia700305.us.archive.org/19/items/TvQuran.com__Abdulkafi/"; 
$linkalkalbany = "http://ia600504.us.archive.org/9/items/TvQuran.com__alkalbany/"; 
$linkathobaity = "http://ia600305.us.archive.org/4/items/TvQuran.com__Athobaity/";
$linkelnajjar = "http://ia600309.us.archive.org/12/items/TvQuran.com__El-Najjar/"; 
$linkMohamadAbdullkarem = "http://ia600402.us.archive.org/9/items/TvQuran.com__Abdlkarem/";
$linkAlHussary = "http://ia700205.us.archive.org/19/items/TvQuran.com__Al-Hussary/";
$linkAlMattrod = "http://ia600405.us.archive.org/2/items/TvQuran.com__Al-Mattrod/"; 
$linkAlQahtani = "http://ia600205.us.archive.org/10/items/TvQuran.com__Al-Qahtani/";
$linkAlQazabri = "http://ia700405.us.archive.org/21/items/TvQuran.com__Al-Qazabri/"; 
$linkSahlYassin = "http://ia600401.us.archive.org/2/items/TvQuran.com__Sahl-Yassin/"; 
$linkAliAlhuthaifi = "http://ia700502.us.archive.org/23/items/TvQuran.com__Ali-Alhuthaifi/"; 



$linkabdelmoujibbenkirane = "http://ia801608.us.archive.org/21/items/tvQuran.com__Benkirane/";
$linkabdlkaber = "http://ia700608.us.archive.org/29/items/TvQuran.com__Abdlkaber/";
$linkAbdulbasit_Mojawwad = "http://ia801703.us.archive.org/9/items/abdelbaset.mjw/";
$linkAbdulmuhsin_Al_Harthy = "http://ia600205.us.archive.org/7/items/TvQuran.com__Harthy/";
$linkabdulqawi_abdulmajid = "http://ia801605.us.archive.org/25/items/tvQuran.com__Abdulqawi/";
$linkabdulrhman_aljuraidy = "http://ia801603.us.archive.org/34/items/tvQuran.com_Abderrahman-aljouraidy/";
$linkabkar = "http://ia801704.us.archive.org/21/items/idabkar/";
$linkahmed_attarabolsi = "http://ia600708.us.archive.org/19/items/tvQuran.com__Attarabolsi/";
$linkahmed_neana = "http://ia600803.us.archive.org/10/items/tvQuran.com__Ahmed-Neana/";
$linkAl_Arkani = "http://tvquranserver.com/download/TvQuran.com__Al-Arkani/";
$linkAl_Asiri = "http://ia600500.us.archive.org/22/items/TvQuran.com__Al-Asiri/";
$linkalbana = "http://ia600302.us.archive.org/15/items/TvQuran.com__Albana/";
$linkalbana_mjwd = "http://ia600309.us.archive.org/19/items/TvQuran.com__Albana-Mjwd/";
$linkAl_Barrak = "http://ia700205.us.archive.org/13/items/TvQuran.com__Al-Barrak/";
$linkalhashim = "http://ia700403.us.archive.org/30/items/TvQuran.com__Alhashim/";
$linkAl_Kandari = "http://ia700403.us.archive.org/2/items/TvQuran.com__Al-Kandari/";
$linkAl_Lohaidan = "http://ia700408.us.archive.org/12/items/TvQuran.com__Al-Lohaidan/";
$linkAl_Minshawi_Mojawwad = "http://ia801703.us.archive.org/21/items/mnshawi-mjd/";
$linkAl_Oni = "http://ia700705.us.archive.org/15/items/TvQuran.com__Lafi/";
$linkAlqatami = "http://ia600406.us.archive.org/28/items/TvQuran.com__Alqatami/";
$linkayman_aldeeb = "http://ia600801.us.archive.org/34/items/tvQuran.com_Ayman-Aldeeb/";
$linkAyyub = "http://ia700400.us.archive.org/10/items/TvQuran.com__Ayyub/";
$linkazzawi = "http://ia600400.us.archive.org/24/items/TvQuran.com__Azzawi/";
$linkelkantaoui = "http://ia700306.us.archive.org/6/items/TvQuran.com__Elkantaoui/";
$linkfouad_alkhamri = "http://ia600808.us.archive.org/31/items/tvQuran.com__Alkhamre/";
$linkhafez_ishak_danish = "http://ia600806.us.archive.org/18/items/tvQuran.com__Ishak-Danish/";
$linkhaneef = "http://ia600507.us.archive.org/7/items/TvQuran.com__Haneef/";
$linkhasan_mohamed_saleh_warsh = "http://ia700801.us.archive.org/10/items/tvQuran.com__Hasan-Mohamed-Saleh-Warsh/";
$linkhawashy = "http://ia700702.us.archive.org/34/items/tvQuran.com__Hawashy/";
$linkjazza_alsuwaileh = "http://ia700803.us.archive.org/14/items/tvQuran.com__Jazza-Alsuwaileh/";
$linkjbreen = "http://ia600406.us.archive.org/21/items/TvQuran.com__jbreen/";
$linkjleel = "http://ia700402.us.archive.org/0/items/TvQuran.com__jleel/";
$linkkoshi = "http://ia600305.us.archive.org/22/items/TvQuran.com__koshi/";
$linklahoni = "http://ia600507.us.archive.org/34/items/TvQuran.com__Al-Lahoni/";
$linkmahmoud_rifai = "http://ia700806.us.archive.org/10/items/tvQuran.com__Mahmoud-AlRefaae/";
$linkMansoor = "http://ia700404.us.archive.org/20/items/TvQuran.com__Mansoor/";
$linkmhsny = "http://ia700403.us.archive.org/16/items/TvQuran.com__Mhsny/";
$linkmohamed_alabdulah = "http://ia700708.us.archive.org/33/items/tvQuran.com__Al-Abdullah/";
$linkmohamed_elhodairi = "http://ia600806.us.archive.org/6/items/tvQuran.com__Elhodairi/";
$linkmohamed_hassan = "http://ia700703.us.archive.org/1/items/tvQuran.com__Mohamed-Hassan/";
$linkmustafaismail = "http://ia700700.us.archive.org/22/items/TvQuran.com__MustafaIsmail/";
$linksalama_hdr = "http://ia700205.us.archive.org/7/items/TvQuran.com__Salama-hdr/";
$linkSami_Al_Hasn = "http://ia700400.us.archive.org/17/items/TvQuran.com__Al-Hasn/";
$linkshakhashero = "http://ia700405.us.archive.org/21/items/TvQuran.com__Shakhashero/";
$linksultan_alrukan = "http://ia700608.us.archive.org/11/items/TvQuran.com__Sultan/";
$linktablawi = "http://ia700303.us.archive.org/15/items/TvQuran.com__Tablawi/";
$linkWalid_Al_Dulaimi = "http://ia801609.us.archive.org/27/items/TvQuran.com__Al-Dulaimi/";
$linkyahya = "http://ia700703.us.archive.org/30/items/TvQuran.com__Yahya/";
$linkyoussef_abkar = "http://ia600403.us.archive.org/26/items/TvQuran.com__Youssef-Abkar/";
$linkyoussef_nouh = "http://ia700803.us.archive.org/0/items/tvQuran.com__Youssef-Nouh-Ahmed/";
$linkzamil = "http://ia700205.us.archive.org/3/items/TvQuran.com__Zamil/";


//////////////// لتحميل المصحف الكامل برابط واحد  //////////////////////

$itemsAlafasi = "http://ia700400.us.archive.org/32/items/TvQuran.com__AlafasiZip/TvQuran.com__Alafasi.zip";
$itemsAlAjmy = "http://ia600205.us.archive.org/13/items/TvQuran.com__Al-AjmyZip/TvQuran.com__Al-Ajmy.zip";
$itemsAbdulbasit = "http://ia600403.us.archive.org/11/items/TvQuran.com__abdulbasitZip/TvQuran.com__abdulbasit.zip";
$itemsAlMinshawi = "http://ia600405.us.archive.org/17/items/TvQuran.com__Al-MinshawiZip/TvQuran.com__Al-Minshawi.zip";
$itemsAlsudaes = "http://ia700401.us.archive.org/4/items/TvQuran.com__AlsdesZip/TvQuran.com__Alsdes.zip";
$itemsAlJohany = "http://ia600405.us.archive.org/21/items/TvQuran.com__Al-JohanyZip/TvQuran.com__Al-Johany.zip";
$itemsmaher = "http://ia600205.us.archive.org/4/items/TvQuran.com__MaherZip/TvQuran.com__Maher.zip";
$itemsAlShuraim = "http://tvquranserver.com/download/TvQuran.com__Al-ShuraimZip/TvQuran.com__Al-Shuraim.zip";
$itemsAlGhamdi = "http://ia600402.us.archive.org/0/items/TvQuran.com__Al-GhamdiZip/TvQuran.com__Al-Ghamdi.zip";
$itemsFares = "http://ia700409.us.archive.org/5/items/TvQuran.com__Fares.AbbadZip/TvQuran.com__Fares.Abbad.zip";



//////////////// لتحميل المصحف الكامل برابط واحد  //////////////////////

$itemsabdulkafi = "http://ia600400.us.archive.org/32/items/TvQuran.com__AbdulkafiZip/TvQuran.com__Abdulkafi.zip";
$itemsadelrayan = "http://ia600403.us.archive.org/34/items/TvQuran.com__RayanZip/TvQuran.com__Rayan.zip";
$itemsAlAhmad = "http://ia600403.us.archive.org/12/items/TvQuran.com__Al-AhmadZip/TvQuran.com__Al-Ahmad.zip";
$itemsalakhdar = "http://ia700405.us.archive.org/28/items/TvQuran.com__AlakhdarZip/TvQuran.com__Alakhdar.zip";
$itemsAlDosari = "#";
$itemsAlHussary = "http://ia600405.us.archive.org/16/items/TvQuran.com__Al-HussaryZip/TvQuran.com__Al-Hussary.zip";
$itemsAliAlhuthaifi = "http://ia600403.us.archive.org/21/items/TvQuran.com__Ali-AlhuthaifiZip/TvQuran.com__Ali-Alhuthaifi.zip";
$itemsalkalbany = "http://ia600403.us.archive.org/25/items/TvQuran.com__AlkalbanyZip/TvQuran.com__Alkalbany.zip";
$itemsAlMattrod = "http://ia600405.us.archive.org/3/items/TvQuran.com__Al-MattrodZip/TvQuran.com__Al-Mattrod.zip";
$itemsAlQahtani = "http://ia600205.us.archive.org/20/items/TvQuran.com__Al-QahtaniZip/TvQuran.com__Al-Qahtani.zip";
$itemsalqasim = "http://ia600403.us.archive.org/35/items/TvQuran.com__AlqasimZip/TvQuran.com__Alqasim.zip";
$itemsAlQazabri = "http://ia600403.us.archive.org/3/items/TvQuran.com__Al-QazabriZip/TvQuran.com__Al-Qazabri.zip";
$itemsathobaity = "http://ia600405.us.archive.org/12/items/TvQuran.com__AthobaityZip/TvQuran.com__Athobaity.zip";
$itemsbasfar = "http://ia600403.us.archive.org/9/items/TvQuran.com__BasfarZip/TvQuran.com__Basfar.zip";
$itemsBukhatir = "http://ia600403.us.archive.org/6/items/TvQuran.com__BukhatirZip/TvQuran.com__Bukhatir.zip";
$itemsdoukkali = "http://ia600400.us.archive.org/8/items/TvQuran.com__DoukkaliZip/TvQuran.com__Doukkali.zip";
$itemsdoukkali = "http://ia600400.us.archive.org/8/items/TvQuran.com__DoukkaliZip/TvQuran.com__Doukkali.zip";
$itemselnajjar = "http://ia600405.us.archive.org/32/items/TvQuran.com__El-NajjarZip/TvQuran.com__El-Najjar.zip";
$itemsHani = "http://ia700403.us.archive.org/12/items/TvQuran.com__HaniZip/TvQuran.com__Hani.zip";
$itemshatem = "http://ia600401.us.archive.org/13/items/TvQuran.com__HatemZip/TvQuran.com__Hatem.zip";
$itemsJaber = "http://ia600405.us.archive.org/6/items/TvQuran.com__JaberZip/TvQuran.com__Jaber.zip";
$itemsjamal = "http://ia700400.us.archive.org/30/items/TvQuran.com__JamalZip/TvQuran.com__Jamal.zip";
$itemsJibrel = "http://ia600405.us.archive.org/28/items/TvQuran.com__JibrelZip/TvQuran.com__Jibrel.zip";
$itemsKanakeri = "http://ia600405.us.archive.org/28/items/TvQuran.com__KanakeriZip/TvQuran.com__Kanakeri.zip";
$itemskhalifa = "http://ia600405.us.archive.org/1/items/TvQuran.com__KhalifahZip/TvQuran.com__Khalifah.zip";
$itemskhayat = "http://ia600405.us.archive.org/18/items/TvQuran.com__KhayatZip/TvQuran.com__Khayat.zip";
$itemsMohamadAbdullkarem = "http://ia700405.us.archive.org/8/items/TvQuran.com__AbdlkaremZip/TvQuran.com__Abdlkarem.zip";
$itemsmuslim = "http://ia600402.us.archive.org/35/items/TvQuran.com__MuslimZip/TvQuran.com__Muslim.zip";
$itemsnabil = "http://ia700403.us.archive.org/27/items/TvQuran.com__NabilZip/TvQuran.com__Nabil.zip";
$itemsSahlYassin = "http://ia600403.us.archive.org/32/items/TvQuran.com__Sahl-YassinZip/TvQuran.com__Sahl-Yassin.zip";
$itemsSalahAlbudair = "http://ia600405.us.archive.org/21/items/TvQuran.com__AlbudairZip/TvQuran.com__Albudair.zip";
$itemsShatri = "http://ia600405.us.archive.org/3/items/TvQuran.com__ShatriZip/TvQuran.com__Shatri.zip";
$itemsShirazadTaher = "http://ia700403.us.archive.org/1/items/TvQuran.com__ShirazadZip/TvQuran.com__Shirazad.zip";
$itemssoufi = "http://ia700403.us.archive.org/14/items/TvQuran.com__soufiZip/TvQuran.com__soufi.zip";
$itemsTawfeeqAsSayegh = "http://ia700403.us.archive.org/6/items/TvQuran.com__TawfeeqZip/TvQuran.com__Tawfeeq.zip";
$itemsyaseen = "http://ia600405.us.archive.org/16/items/TvQuran.com__YaseenZip/TvQuran.com__Yaseen.zip";
$itemsyoussef = "http://ia600409.us.archive.org/10/items/TvQuran.com__YoussefZip/TvQuran.com__Youssef.zip";
$itemszain = "http://ia600403.us.archive.org/34/items/TvQuran.com__ZainZip/TvQuran.com__Zain.zip";
$itemszaki = "http://ia600405.us.archive.org/23/items/TvQuran.com__ZakiZip/TvQuran.com__Zaki.zip";
$linkhd ="
<div class='crt2'>
<div class='crt-r'> <h3> اذكار الصباح والمساء </h3> </div>
<div class='crt'>
<marquee direction='right' > لا الـه الا الله وحده لا شريك له، له الملك ، وله الحمد ، وهو على كل شيء قدير,اللهم إني اعوذ بك ان اشرك بك وانا اعلم، واستغفرك لما لا اعلم,(( اللهم لك صمت وعلى رزقك افطرت فتقبل منا انك أنت السميع العليم,اللهم إني اسألك برحمتك التي وسعت كل شيء أن تغفر لي,ذهب الظماء وابتلت العروق وثبت الاجر ان شاء الله)),سبحانك اللهم وبحمدك أشهد أن لا ألـه إلا أنت، استغفرك وأتوب اليك, اللهم اغفر لي ، وارحمني ، واهدني، وعافين و ارزقني , لا الـه الا الله وحده لا شريك له، له الملك ، وله الحمد ، وهو على كل شيء قدير</marquee>
</div>
</div>
";


?>
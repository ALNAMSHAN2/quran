<?php
include "templates/main-Quran.html";
?>

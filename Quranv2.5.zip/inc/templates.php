<?php
$minhader="
<div class='min'>";
$minfooter="</div>";

?>
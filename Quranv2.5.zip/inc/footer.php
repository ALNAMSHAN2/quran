<?php
include "templates/footer.html";
?>
</body>
</html>
<?php
$Abdulbasit[1] = "http://www.archive.org/download/TvQuran.com__basit/"; 
$Abdulbasit_Mojawwad[2] = "http://www.archive.org/download/TvQuran.com__basit_mjwd/"; 
$Alafasi[3] = "http://live.islamweb.net/quran/MeshariAl3affasy/"; 
$Al-Ajmy[4] = "http://www.archive.org/download/TvQuran.com__Al-Ajmy/"; 
$Al-Ghamdi[5] = "http://www.archive.org/download/TvQuran.com__Al-Ghamdi/"; 
$Al-Johany[6] = "http://live.islamweb.net/quran/AbdullahAwwadAljahny/"; 
$Al-Minshawi[7] = "http://www.archive.org/download/TvQuran.com__Al-Minshawi/"; 
$Al-Minshawi_Mojawwad[8] = "http://www.archive.org/download/TvQuran.com__Al-Minshawi-Mojawad/"; 
$Al-Shuraim[9] = "http://www.archive.org/download/TvQuran.com__Al-Shuraim/";
$Al-sudaes[10] = "http://live.islamweb.net/quran/Sudeas/";
$Fares[11] = "http://www.archive.org/download/TvQuran.com__Fares.Abbad/"; 
$Maher[12] = "http://www.archive.org/download/TvQuran.com__Maher/";

print $LANGUAGE[1];

?>
<?php
//-------------------------------------------///
//          Quran    v2.1                   ///
//        ���� ������� ���������   v2.1                  ///
//         ������ ������                         ///
//   http://www.sedany.com              ///
//        ���� ������ ������ ������                  ///
//         ����� ������ ������                   ///
//     sedany@sedany.com             ///
//----------------------------------///

////////////////�� ��� ������ ��� ������� //////////////////////

//------------------linkadel-rayan -------------------------///
$linkadel-rayan = "http://ia600400.us.archive.org/5/items/TvQuran.com__Ryan/";
//---///

//------------------linkHani -------------------------///
$linkHani = "http://ia600404.us.archive.org/21/items/TvQuran.com__Hani/";
//---///

//------------------linkhatem -------------------------///
$linkhatem = "http://ia700106.us.archive.org/1/items/TvQuran.com__Hatem/";
//---///

//------------------linkJaber -------------------------///
$linkJaber = "http://download.tvquran.com/download/TvQuran.com__Jaber/";
//---///

//------------------linksoufi -------------------------///
$linksoufi = "http://ia600402.us.archive.org/6/items/TvQuran.com__soufi/";
//---///

//------------------linkzain -------------------------///
$linkzain = "http://ia600309.us.archive.org/26/items/TvQuran.com__Zain/";
//---///

//------------------linkzaki -------------------------///
$linkzaki = "http://ia600305.us.archive.org/11/items/TvQuran.com__Zaki/";
//---///

//------------------linkAbdulbasit -------------------------///
$linkAbdulbasit = "http://ia600205.us.archive.org/19/items/TvQuran.com__basit/";
//---///

//------------------linkbasfar -------------------------///
$linkbasfar = "http://ia600209.us.archive.org/1/items/TvQuran.com__Basfar/";
//---///

//------------------linkjamal -------------------------///
$linkjamal = "http://ia600300.us.archive.org/33/items/TvQuran.com__Jamal/";
//---///

//------------------linkMaher -------------------------///
$linkMaher = "http://ia600205.us.archive.org/15/items/TvQuran.com__Maher/";
//---///

//------------------linknabil -------------------------///
$linknabil = "http://ia600209.us.archive.org/11/items/TvQuran.com__Nabil/";
//---///

//------------------linkAl-Dosari -------------------------///
$linkAl-Dosari = "http://ia600205.us.archive.org/23/items/TvQuran.com__Yasser/";
//---///

//------------------linkAli-Alhuthaifi -------------------------///
$linkAli-Alhuthaifi = "http://www.archive.org/download/TvQuran.com__Ali-Alhuthaifi/";
//---///

//------------------linkal-qasim -------------------------///
$linkal-qasim = "http://ia600400.us.archive.org/5/items/TvQuran.com__Alqasim/";
//---///

//------------------linkAl-sudaes -------------------------///
$linkAl-sudaes = "http://ia600205.us.archive.org/23/items/TvQuran.com__Alsdes/";
//---///

//------------------linkJibrel -------------------------///
$linkJibrel = "http://ia600402.us.archive.org/34/items/TvQuran.com__Jibrel/";
//---///

//------------------linkkhayat -------------------------///
$linkkhayat = "http://ia600302.us.archive.org/11/items/TvQuran.com__Khayat/";
//---///

//------------------linkmuslim -------------------------///
$linkmuslim = "http://ia600305.us.archive.org/23/items/TvQuran.com__Muslim/";
//---///

//------------------linkShatri -------------------------///
$linkShatri = "http://ia600102.us.archive.org/13/items/TvQuran.com__Shatri/";
//---///


//------------------linkyaseen -------------------------///
$linkyaseen = "http://ia700305.us.archive.org/21/items/TvQuran.com__Yaseen/";
//---///

//------------------linkyoussef -------------------------///
$linkyoussef = "http://ia700102.us.archive.org/7/items/TvQuran.com__Youssef/";
//---///

//------------------linkAlafasi -------------------------///
$linkAlafasi = "http://ia600104.us.archive.org/21/items/TvQuran.com__Alafasi/";
//---///

//------------------linkAl-Ahmad -------------------------///
$linkAl-Ahmad = "http://ia600108.us.archive.org/7/items/TvQuran.com__Al-Ahmad/";
//---///

//------------------linkBukhatir -------------------------///
$linkBukhatir = "http://ia600400.us.archive.org/2/items/TvQuran.com__Bukhatir/";
//---///


//------------------linkKanakeri -------------------------///
$linkKanakeri = "http://ia600403.us.archive.org/0/items/TvQuran.com__Kanakeri/";
//---///

//------------------linkTawfeeq-As-Sayegh -------------------------///
$linkTawfeeq-As-Sayegh = "http://ia600407.us.archive.org/11/items/TvQuran.com__Tawfeeq/";
//---///

//------------------linkAl-Ajmy -------------------------///
$linkAl-Ajmy = "http://ia700205.us.archive.org/1/items/TvQuran.com__Al-Ajmy/";
//---///

//------------------linkalakhdar -------------------------///
$linkalakhdar = "http://ia600105.us.archive.org/12/items/tvQuran.com__Alakhdar/";
//---///

//------------------linkalkalbany -------------------------///
$linkalkalbany = "http://ia600104.us.archive.org/9/items/TvQuran.com__alkalbany/";
//---///


//------------------linkathobaity -------------------------///
$linkathobaity = "http://ia600305.us.archive.org/4/items/TvQuran.com__Athobaity/";
//---///

//------------------linkdoukkali -------------------------///
$linkdoukkali = "http://download.tvquran.com/download/TvQuran.com__doukkali/";
//---///

//------------------linkkhalifa -------------------------///
$linkkhalifa = "http://ia600105.us.archive.org/23/items/TvQuran.com__Khalifah/";
//---///

//------------------linkMohamad-Abdullkarem -------------------------///
$linkMohamad-Abdullkarem = "http://ia600402.us.archive.org/9/items/TvQuran.com__Abdlkarem/";
//---///

//------------------linkSalah-Albudair -------------------------///
$linkSalah-Albudair = "http://ia600404.us.archive.org/21/items/TvQuran.com__Albudair/";
//---///

//------------------linkShirazad-Taher -------------------------///
$linkShirazad-Taher = "http://ia600408.us.archive.org/30/items/TvQuran.com__Shirazad/";
//---///

//------------------linkAl-Johany -------------------------///
$linkAl-Johany = "http://ia700308.us.archive.org/15/items/TvQuran.com__Al-Johany/";
//---///

//------------------linkabdulkafi -------------------------///
$linkabdulkafi = "http://ia700305.us.archive.org/19/items/TvQuran.com__Abdulkafi/";
//---///

//------------------linkAl-Mattrod -------------------------///
$linkAl-Mattrod = "http://ia600405.us.archive.org/2/items/TvQuran.com__Al-Mattrod/";
//---///

//------------------linkel-najjar -------------------------///
$linkel-najjar = "http://ia600309.us.archive.org/12/items/TvQuran.com__El-Najjar/";
//---///

//------------------linkAl-Ghamdi -------------------------///
$linkAl-Ghamdi = "http://ia700205.us.archive.org/23/items/TvQuran.com__Al-Ghamdi/";
//---///

//------------------linkAl-Hussary -------------------------///
$linkAl-Hussary = "http://download.tvquran.com/download/TvQuran.com__Al-Hussary/";
//---///

//------------------linkAl-Minshawi -------------------------///
$linkAl-Minshawi = "http://ia600200.us.archive.org/3/items/TvQuran.com__Al-Minshawi/";
//---///

//------------------linkAl-Qahtani -------------------------///
$linkAl-Qahtani = "http://ia600205.us.archive.org/10/items/TvQuran.com__Al-Qahtani/";
//---///

//------------------linkAl-Qazabri -------------------------///
$linkAl-Qazabri = "http://download.tvquran.com/download/TvQuran.com__Al-Qazabri/";
//---///


//------------------linkFares -------------------------///
$linkFares = "http://ia600209.us.archive.org/6/items/TvQuran.com__Fares.Abbad/";
//---///

//------------------linkSahl-Yassin -------------------------///
$linkSahl-Yassin = "http://ia600401.us.archive.org/2/items/TvQuran.com__Sahl-Yassin/";
//---///

//------------------linkAl-Shuraim -------------------------///
$linkAl-Shuraim = "http://ia600305.us.archive.org/5/items/TvQuran.com__Al-Shuraim/";
//---///

//------------------linkAbdulbasit_Mojawwad -------------------------///
$linkAbdulbasit_Mojawwad = "http://ia600106.us.archive.org/18/items/TvQuran.com__basit_mjwd/";
//---///


//------------------linkAl-Minshawi_Mojawwad -------------------------///
$linkAl-Minshawi_Mojawwad = "http://ia600205.us.archive.org/19/items/TvQuran.com__Al-Minshawi-Mojawad/";
//---///

//------------------link -------------------------///
$link = "";
//---///

//------------------link -------------------------///
$link = "";
//---///

?>